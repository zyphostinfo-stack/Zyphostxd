/* ZypeHost Minecraft-only Cloudflare subdomains + injected server navigation tab. Loaded by wrapper.blade.php. */
(function () {
    'use strict';

    var DOMAIN = 'blocknova.de';
    var lastServer = '';
    var lastEligibility = null;
    var lastData = null;
    var requestBusy = false;
    var root = null;

    function serverContext() {
        var match = window.location.pathname.match(/\/server\/([^/]+)(?:\/|$)/i);
        if (!match) return null;
        return { id: decodeURIComponent(match[1]), onSubdomains: /\/subdomains?\/?$/i.test(window.location.pathname) };
    }

    function csrfToken() {
        var node = document.querySelector('meta[name="csrf-token"]');
        return node ? node.getAttribute('content') || '' : '';
    }

    function endpoint(serverId) {
        return '/api/client/servers/' + encodeURIComponent(serverId) + '/zypehost-subdomains';
    }

    function api(serverId, method, path, body) {
        var headers = { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' };
        var csrf = csrfToken();
        if (csrf) headers['X-CSRF-TOKEN'] = csrf;
        if (body !== undefined) headers['Content-Type'] = 'application/json';
        return fetch(endpoint(serverId) + (path || ''), {
            method: method || 'GET',
            credentials: 'same-origin',
            headers: headers,
            body: body === undefined ? undefined : JSON.stringify(body),
        }).then(function (response) {
            return response.text().then(function (raw) {
                var data = {};
                try { data = raw ? JSON.parse(raw) : {}; } catch (_) { data = { message: raw || 'Ungültige Serverantwort.' }; }
                if (!response.ok) {
                    var error = new Error(data.message || ('HTTP ' + response.status));
                    error.status = response.status;
                    error.data = data;
                    throw error;
                }
                return data;
            });
        });
    }

    function escapeHtml(value) {
        return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
        });
    }

    function serverNavLinks(serverId) {
        var safeId = String(serverId || '');
        return Array.prototype.slice.call(document.querySelectorAll('a[href]')).filter(function (anchor) {
            try {
                var path = new URL(anchor.getAttribute('href') || '', window.location.href).pathname;
                var match = path.match(/^\/server\/([^/]+)\/(console|files|databases|schedules|users|backups|network|startup|settings|activity)(?:\/.*)?$/i);
                return !!match && decodeURIComponent(match[1]) === safeId;
            } catch (_) { return false; }
        });
    }

    function findServerNavContainer(links) {
        if (!links || !links.length) return null;
        var node = links[0].parentElement;
        while (node && node !== document.body) {
            var found = Array.prototype.slice.call(node.querySelectorAll('a[href]')).filter(function (anchor) {
                return links.indexOf(anchor) !== -1;
            });
            if (found.length >= Math.min(5, links.length)) return node;
            node = node.parentElement;
        }
        return links[0].parentElement;
    }

    function styleSubdomainTab(tab, active) {
        if (!tab) return;
        tab.style.display = '';
        tab.style.whiteSpace = 'nowrap';
        tab.style.cursor = 'pointer';
        tab.style.textDecoration = 'none';
        tab.style.borderBottom = active ? '2px solid #95c900' : '2px solid transparent';
        tab.style.color = active ? '#d7f2a0' : '';
        tab.setAttribute('aria-current', active ? 'page' : 'false');
    }

    function ensureSubdomainTab(serverId, visible, active) {
        var tab = document.querySelector('[data-zypehost-subdomain-tab="1"]');
        if (!visible || !serverId) {
            if (tab) tab.style.display = 'none';
            return;
        }

        var links = serverNavLinks(serverId);
        if (!links.length) {
            if (tab) tab.style.display = 'none';
            return;
        }

        var path = '/server/' + encodeURIComponent(serverId) + '/subdomains';
        var container = findServerNavContainer(links);
        if (!container) return;

        // Reuse the native navigation element's CSS classes so the new item
        // looks like Console / Files / Network, but do not copy its active state.
        var reference = links.filter(function (a) {
            return !a.getAttribute('aria-current') && !/border-b-|text-primary|text-green/i.test(a.className || '');
        })[0] || links[0];

        if (!tab || !document.body.contains(tab) || tab.getAttribute('data-server-id') !== serverId) {
            if (tab) tab.remove();
            tab = document.createElement('a');
            tab.setAttribute('data-zypehost-subdomain-tab', '1');
            tab.setAttribute('data-server-id', serverId);
            tab.setAttribute('href', path);
            tab.className = reference.className || '';
            if (reference.getAttribute('style')) tab.setAttribute('style', reference.getAttribute('style'));
            var referenceSpan = reference.querySelector('span');
            if (referenceSpan) {
                var label = document.createElement('span');
                label.className = referenceSpan.className || '';
                label.textContent = 'Subdomain';
                tab.appendChild(label);
            } else {
                tab.textContent = 'Subdomain';
            }
            tab.addEventListener('click', function (event) {
                // This is a script-rendered page, not a React route. Keep the
                // current SPA view mounted and let our overlay handle the URL.
                event.preventDefault();
                event.stopPropagation();
                var nextPath = '/server/' + encodeURIComponent(serverId) + '/subdomains';
                if (window.location.pathname !== nextPath) {
                    window.history.pushState({ zypehostSubdomains: true }, '', nextPath);
                }
                scheduleSync();
            });

            var network = links.filter(function (a) { return /\/network(?:\/|$)/i.test(a.getAttribute('href') || ''); })[0];
            var insertAfter = network || links[links.length - 1];
            var isList = /^(UL|OL)$/.test(container.tagName || '');
            var wrapper = null;
            var linkParent = insertAfter.parentElement;
            if (isList) {
                wrapper = document.createElement('li');
                wrapper.className = (linkParent && linkParent.tagName === 'LI') ? linkParent.className : '';
                wrapper.appendChild(tab);
                // Insert beside the existing list item, not inside it. Nesting
                // an <li> within another <li> makes the tab disappear or
                // renders it incorrectly in browsers and mobile WebViews.
                if (linkParent && linkParent.parentElement === container) {
                    linkParent.insertAdjacentElement('afterend', wrapper);
                } else {
                    insertAfter.insertAdjacentElement('afterend', wrapper);
                }
            } else if (linkParent && linkParent !== container && linkParent.parentElement === container) {
                // Several panel builds wrap each nav link in its own flex item.
                // Clone the wrapper and add it as a sibling, rather than
                // inserting a wrapper inside the link's existing flex item.
                wrapper = linkParent.cloneNode(false);
                wrapper.appendChild(tab);
                linkParent.insertAdjacentElement('afterend', wrapper);
            } else {
                insertAfter.insertAdjacentElement('afterend', tab);
            }
        } else {
            tab.setAttribute('href', path);
        }

        styleSubdomainTab(tab, !!active);
    }

    function setSubdomainTabVisible(visible, serverId, active) {
        if (serverId) {
            ensureSubdomainTab(serverId, visible, active);
        } else {
            var tab = document.querySelector('[data-zypehost-subdomain-tab="1"]');
            if (tab) tab.style.display = 'none';
        }
        // Hide any legacy tab provided by a different plugin for non-Minecraft
        // servers, but do not depend on one existing in the first place.
        Array.prototype.slice.call(document.querySelectorAll('a[href]')).filter(function (anchor) {
            if (anchor.hasAttribute('data-zypehost-subdomain-tab')) return false;
            var href = anchor.getAttribute('href') || '';
            var label = (anchor.textContent || '').trim().toLowerCase();
            return /\/subdomains?(?:\/|$)/i.test(href) || label === 'subdomain' || label === 'subdomains';
        }).forEach(function (anchor) {
            var item = anchor.closest('li') || anchor.parentElement || anchor;
            item.style.display = visible ? '' : 'none';
        });
    }

    function ensureRoot() {
        if (root && document.body.contains(root)) return root;
        root = document.getElementById('zypehost-subdomain-ui');
        if (root) return root;
        root = document.createElement('div');
        root.id = 'zypehost-subdomain-ui';
        root.style.cssText = 'display:none;position:fixed;z-index:9998;top:54px;left:0;right:0;bottom:0;overflow:auto;background:#0e111b;color:#e9eef8;font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif;padding:26px 22px 40px;box-sizing:border-box;';
        document.body.appendChild(root);
        return root;
    }

    function showMessage(message, kind) {
        var node = root && root.querySelector('[data-zypehost-message]');
        if (!node) return;
        node.textContent = message;
        node.style.display = message ? 'block' : 'none';
        node.style.color = kind === 'error' ? '#fecaca' : '#bbf7d0';
        node.style.background = kind === 'error' ? 'rgba(127,29,29,.24)' : 'rgba(20,83,45,.24)';
    }

    function renderLoading() {
        var r = ensureRoot();
        r.innerHTML = '<div style="max-width:980px;margin:10px auto"><div style="color:#93a4bd">ZypeHost · Minecraft Subdomains</div><h1 style="font-size:26px;margin:10px 0 8px;color:#fff">Subdomains</h1><p style="color:#94a3b8">Cloudflare-DNS wird geladen …</p></div>';
    }

    function renderNotMinecraft() {
        var r = ensureRoot();
        r.innerHTML = '<div style="max-width:900px;margin:32px auto;padding:26px;border:1px solid #293244;border-radius:14px;background:#151a27"><h2 style="margin:0 0 8px;color:#fff">Subdomains nur für Minecraft</h2><p style="color:#a8b5c9;margin:0">Diese Funktion ist ausschließlich für Minecraft-Server freigeschaltet.</p></div>';
    }

    function render(data, serverId) {
        lastServer = serverId;
        lastEligibility = true;
        lastData = data;
        var r = ensureRoot();
        var allocations = Array.isArray(data.allocations) ? data.allocations : [];
        var rows = Array.isArray(data.subdomains) ? data.subdomains : [];
        var allocationOptions = allocations.map(function (item) {
            return '<option value="' + escapeHtml(item.id) + '">' + escapeHtml(item.label) + '</option>';
        }).join('');
        var subdomainRows = rows.length ? rows.map(function (item) {
            return '<div class="zy-row"><div style="min-width:0"><div style="font-weight:700;color:#fff;overflow-wrap:anywhere">' + escapeHtml(item.fqdn) + '</div><small style="color:#93a4bd">' + escapeHtml(item.ip) + ':' + escapeHtml(item.port) + '</small></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="zy-copy" data-copy="' + escapeHtml(item.fqdn) + '">Kopieren</button><button type="button" class="zy-delete" data-delete="' + escapeHtml(item.id) + '">Löschen</button></div></div>';
        }).join('') : '<p style="color:#93a4bd;margin:12px 0">Du hast noch keine Subdomain für diesen Minecraft-Server.</p>';

        r.innerHTML = '' +
            '<div class="zy-wrap">' +
                '<div style="display:flex;align-items:flex-end;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:20px">' +
                    '<div><div style="color:#8da3c4;font-size:12px;letter-spacing:.12em;text-transform:uppercase">ZypeHost · Minecraft</div><h1 style="font-size:27px;line-height:1.2;margin:8px 0 5px;color:#fff">Subdomains</h1><p style="color:#9cabc2;margin:0">Erstelle eine eigene Minecraft-Adresse für deinen Server.</p></div>' +
                    '<div style="padding:9px 13px;border:1px solid #334155;border-radius:9px;color:#b6c5dc;background:#151c29">Nur <strong style="color:#fff">' + DOMAIN + '</strong></div>' +
                '</div>' +
                '<div data-zypehost-message style="display:none;margin-bottom:16px;padding:12px 14px;border-radius:9px"></div>' +
                '<section class="zy-card"><h2>Subdomain erstellen</h2>' +
                    '<form id="zy-create-form">' +
                        '<label>SUBDOMAIN<input id="zy-subdomain" name="subdomain" type="text" maxlength="48" minlength="2" pattern="[a-z0-9][a-z0-9-]*[a-z0-9]" placeholder="survival" required autocomplete="off" /></label>' +
                        '<label>DOMAIN<select disabled><option>' + DOMAIN + '</option></select></label>' +
                        '<label>ALLOCATION<select id="zy-allocation" required>' + (allocationOptions || '<option value="">Keine öffentliche Allocation verfügbar</option>') + '</select></label>' +
                        '<button class="zy-create" type="submit" ' + (allocations.length ? '' : 'disabled') + '>Create Subdomain</button>' +
                    '</form>' +
                    '<small style="display:block;color:#91a0b6;margin-top:12px">Minecraft Java kann bei einem abweichenden Port ohne Portangabe beitreten (SRV-DNS). Cloudflare-Proxy bleibt deaktiviert.</small>' +
                '</section>' +
                '<section class="zy-card" style="margin-top:18px"><h2>Deine Subdomains</h2><div id="zy-list">' + subdomainRows + '</div></section>' +
                '<div style="color:#718198;font-size:12px;margin-top:18px">Domain fest vorgegeben: ' + DOMAIN + ' · Nur Minecraft-Eggs sind serverseitig zugelassen.</div>' +
            '</div>';

        var style = document.createElement('style');
        style.id = 'zypehost-subdomains-style';
        style.textContent = '#zypehost-subdomain-ui .zy-wrap{max-width:980px;margin:0 auto}#zypehost-subdomain-ui .zy-card{background:#151b28;border:1px solid #2b3547;border-radius:13px;padding:20px 22px;box-shadow:0 12px 30px rgba(0,0,0,.18)}#zypehost-subdomain-ui .zy-card h2{font-size:18px;color:#f8fafc;margin:0 0 17px}#zypehost-subdomain-ui form{display:grid;grid-template-columns:1fr 1fr;gap:15px}#zypehost-subdomain-ui label{display:flex;flex-direction:column;gap:8px;color:#aab8cc;font-size:11px;font-weight:700;letter-spacing:.06em}#zypehost-subdomain-ui input,#zypehost-subdomain-ui select{height:43px;box-sizing:border-box;width:100%;border:1px solid #49586d;border-radius:8px;background:#465365;color:#fff;padding:0 12px;font-size:14px;outline:none}#zypehost-subdomain-ui select:disabled{opacity:.9}#zypehost-subdomain-ui input:focus,#zypehost-subdomain-ui select:focus{border-color:#9ac600;box-shadow:0 0 0 2px rgba(154,198,0,.16)}#zypehost-subdomain-ui .zy-create{grid-column:1/-1;justify-self:start;border:0;border-radius:9px;background:#95c900;color:#10170a;font-weight:800;padding:12px 18px;cursor:pointer}#zypehost-subdomain-ui .zy-create:disabled{opacity:.5;cursor:not-allowed}#zypehost-subdomain-ui .zy-row{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:14px 0;border-bottom:1px solid #293548}#zypehost-subdomain-ui .zy-row:last-child{border-bottom:0}#zypehost-subdomain-ui .zy-copy,#zypehost-subdomain-ui .zy-delete{border:1px solid #42516a;background:#222d3e;color:#e9eef8;border-radius:8px;padding:8px 12px;cursor:pointer}#zypehost-subdomain-ui .zy-delete{border-color:#7f333b;color:#fecaca}@media(max-width:650px){#zypehost-subdomain-ui{top:50px;padding:18px 12px}#zypehost-subdomain-ui form{grid-template-columns:1fr}#zypehost-subdomain-ui .zy-row{align-items:flex-start;flex-direction:column}}';
        var oldStyle = document.getElementById('zypehost-subdomains-style');
        if (oldStyle) oldStyle.remove();
        document.head.appendChild(style);

        var form = r.querySelector('#zy-create-form');
        if (form) form.addEventListener('submit', function (event) {
            event.preventDefault();
            if (requestBusy) return;
            requestBusy = true;
            var button = form.querySelector('button[type="submit"]');
            button.disabled = true;
            button.textContent = 'Wird erstellt …';
            showMessage('', 'success');
            api(serverId, 'POST', '', {
                subdomain: r.querySelector('#zy-subdomain').value.trim().toLowerCase(),
                allocation_id: Number(r.querySelector('#zy-allocation').value),
            }).then(function () {
                showMessage('Subdomain wurde in Cloudflare erstellt.', 'success');
                return api(serverId, 'GET', '');
            }).then(function (latest) {
                render(latest, serverId);
            }).catch(function (error) {
                showMessage(error.message || 'Die Subdomain konnte nicht erstellt werden.', 'error');
                button.disabled = false;
                button.textContent = 'Create Subdomain';
            }).finally(function () { requestBusy = false; });
        });

        r.querySelectorAll('[data-delete]').forEach(function (button) {
            button.addEventListener('click', function () {
                var id = button.getAttribute('data-delete');
                if (!window.confirm('Subdomain und DNS-Einträge wirklich löschen?')) return;
                button.disabled = true;
                api(serverId, 'DELETE', '/' + encodeURIComponent(id)).then(function () {
                    return api(serverId, 'GET', '');
                }).then(function (latest) {
                    render(latest, serverId);
                    showMessage('Subdomain wurde gelöscht.', 'success');
                }).catch(function (error) {
                    button.disabled = false;
                    showMessage(error.message || 'Löschen fehlgeschlagen.', 'error');
                });
            });
        });

        r.querySelectorAll('[data-copy]').forEach(function (button) {
            button.addEventListener('click', function () {
                var text = button.getAttribute('data-copy');
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(text).then(function () { showMessage('Adresse kopiert: ' + text, 'success'); });
                } else {
                    showMessage('Adresse: ' + text, 'success');
                }
            });
        });
    }

    function loadServer(serverId) {
        if (lastServer === serverId && lastEligibility !== null) return Promise.resolve({ eligible: lastEligibility, data: lastData });
        return api(serverId, 'GET', '').then(function (data) {
            lastServer = serverId;
            lastEligibility = true;
            lastData = data;
            return { eligible: true, data: data };
        }).catch(function (error) {
            if (error.data && error.data.code === 'minecraft_only') {
                lastServer = serverId;
                lastEligibility = false;
                lastData = null;
                return { eligible: false };
            }
            return { eligible: null, error: error };
        });
    }

    function sync() {
        var context = serverContext();
        var r = ensureRoot();
        if (!context) {
            r.style.display = 'none';
            setSubdomainTabVisible(false);
            lastServer = '';
            lastEligibility = null;
            lastData = null;
            return;
        }

        loadServer(context.id).then(function (result) {
            if (result.eligible === false) {
                setSubdomainTabVisible(false, context.id, false);
                if (context.onSubdomains) {
                    r.style.display = 'block';
                    renderNotMinecraft();
                } else {
                    r.style.display = 'none';
                }
                return;
            }

            if (result.eligible === true) {
                setSubdomainTabVisible(true, context.id, context.onSubdomains);
                if (context.onSubdomains) {
                    r.style.display = 'block';
                    render(result.data, context.id);
                } else {
                    r.style.display = 'none';
                }
                return;
            }

            // Keep the existing extension visible if the API cannot be reached;
            // do not incorrectly hide the navigation because of a transient error.
            setSubdomainTabVisible(true, context.id, context.onSubdomains);
            if (context.onSubdomains) {
                r.style.display = 'block';
                renderLoading();
                var wrap = r.querySelector('p');
                if (wrap) wrap.textContent = result.error && result.error.message ? result.error.message : 'Subdomain-Funktion konnte nicht geladen werden.';
            } else {
                r.style.display = 'none';
            }
        });
    }

    var queued = false;
    function scheduleSync() {
        if (queued) return;
        queued = true;
        window.setTimeout(function () { queued = false; sync(); }, 180);
    }

    ['pushState', 'replaceState'].forEach(function (method) {
        var original = history[method];
        history[method] = function () {
            var result = original.apply(this, arguments);
            scheduleSync();
            return result;
        };
    });
    window.addEventListener('popstate', scheduleSync);
    document.addEventListener('DOMContentLoaded', scheduleSync);
    document.addEventListener('DOMContentLoaded', function () {
        var app = document.getElementById('app');
        if (app) new MutationObserver(scheduleSync).observe(app, { childList: true, subtree: true });
        scheduleSync();
    });
    scheduleSync();
})();
