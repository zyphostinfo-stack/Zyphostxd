# ZypeHost Pterodactyl Theme v21.0.3

GitHub-fertiges Komplettpaket für das von Bennetlolll betriebene Pterodactyl-Panel. Das ZIP ist flach aufgebaut: `install.sh` liegt im obersten Ordner. Enthalten sind das bestehende ZypeHost-Theme, Discord-/Google-OAuth und die Minecraft-only Subdomain-Verwaltung über Cloudflare für genau `blocknova.de`.

## Enthaltene Funktionen

- ZypeHost Login- und Dashboard-Design, Logo, Hintergrund und Favicons.
- Normale Pterodactyl-Anmeldung mit E-Mail/Benutzername und Passwort bleibt erhalten.
- Discord- und Google-OAuth mit State-Prüfung und verifizierter E-Mail.
- Google- und Discord-Anmeldung stehen in der mobilen Login-Ansicht sichtbar über dem Passwort-Formular.
- Fügt den Tab „Subdomain“ selbst in die Servernavigation ein (direkt neben „Network“); es wird kein Drittanbieter-Tab vorausgesetzt.
- Korrigiert die Einfügestelle des Tabs in Listen- und Flex-Menüs, damit er als echter Menüpunkt direkt neben „Network“ erscheint.
- Server-Menüeinträge umbrechen auf schmalen Handybildschirmen in mehrere Zeilen statt abgeschnitten zu werden.
- Prüft nach dem Frontend-Build, ob das Haupt-JavaScript-Bundle vorhanden ist; ein fehlendes Bundle lässt nur den Dashboard-Hintergrund stehen.
- Für Nicht-Minecraft-Eggs wird der Subdomain-Tab ausgeblendet; das Backend verweigert Anfragen für Nicht-Minecraft-Server zusätzlich serverseitig.
- Kunden können ausschließlich eine Adresse unter `blocknova.de` erstellen.
- Cloudflare erstellt für jede Subdomain einen nicht proxied A-Record. Bei Minecraft-Ports ungleich 25565 wird außerdem ein `_minecraft._tcp`-SRV-Record erstellt, damit Java-Spieler ohne Portangabe beitreten können.
- Subdomains können wieder gelöscht werden; das Backend löscht nur die in der ZypeHost-Datenbank gespeicherten Cloudflare-Record-IDs.
- Serverbesitzer und Root-Admins dürfen verwalten. Subuser brauchen die entsprechenden Pterodactyl-Allocation-Berechtigungen.
- Allocation-IP und -Port werden aus den dem Server zugewiesenen Pterodactyl-Allocations gelesen. Private IPs werden nicht als öffentliche DNS-Ziele akzeptiert; optional können öffentliche Node-IPs in der `.env` hinterlegt werden.
- Backup, Deinstallation, Reset und Paketprüfung.

## Wichtige technische Voraussetzungen

Das Paket zielt auf die vom Betreiber angegebene Panel-Struktur:

- Panel: `/var/www/pterodactyl`
- Auth-Routen: `routes/auth.php`
- Client-API-Routen: `routes/api-client.php`
- Login-Komponente: `resources/scripts/components/auth/LoginFormContainer.tsx`
- Blade-Wrapper: `resources/views/templates/wrapper.blade.php`
- Pterodactyl-Client-Middleware `ServerSubject`, `AuthenticateServerAccess` und `ResourceBelongsToServer`

Das Frontend-Skript fügt nach erfolgreicher Minecraft-Prüfung einen eigenen Navigationspunkt „Subdomain“ neben „Network“ ein. Ein Klick öffnet die mitgelieferte Subdomain-Oberfläche als Panel-Overlay unter `/server/{identifier}/subdomains`; eine bereits vorhandene Subdomain-Erweiterung ist nicht erforderlich. Bei Nicht-Minecraft-Eggs wird der Tab ausgeblendet und das Backend verweigert die API-Anfragen zusätzlich.

Benötigt werden PHP 8.x mit Laravel/Pterodactyl-Abhängigkeiten, Python 3, Node.js und Yarn oder npm sowie eine funktionierende Datenbankverbindung.

## GitHub-Upload

1. ZIP herunterladen und lokal entpacken.
2. Alle Dateien und Ordner aus dem entpackten Inhalt direkt in das Hauptverzeichnis von `https://github.com/Bennetlolll/Newwww` hochladen.
3. Gleichnamige Dateien ersetzen und `Commit changes` ausführen.
4. Prüfen, dass `install.sh`, `backend/`, `scripts/` und `theme/` direkt auf der ersten Repository-Ebene liegen.
5. Nur `.env.example` hochladen. Eine echte Panel-`.env`, API-Token oder OAuth-Client-Secrets gehören niemals zu GitHub.

## Wenn nur der Hintergrund erscheint

Dann startet das Pterodactyl-Frontend wahrscheinlich nicht. Der Browser muss `/assets/bundle.<hash>.js` als JavaScript laden; wenn dieser Pfad stattdessen HTML oder `text/html` liefert, ist das Frontend-Bundle nicht erreichbar. Nach dem Hochladen des Pakets kann der Frontend-Build gezielt erneut ausgeführt werden:

```bash
cd /root/Newwww
PTERODACTYL_DIR=/var/www/pterodactyl bash scripts/rebuild-frontend.sh
```

Das Skript baut nur das vorhandene Pterodactyl-Frontend neu, leert den Laravel-Cache und prüft, ob ein JavaScript-Bundle erzeugt wurde. Falls der Build fehlschlägt, ist die Fehlermeldung aus diesem Lauf entscheidend.

## Cloudflare vorbereiten

Erstelle bei Cloudflare einen API Token, der ausschließlich für die Zone `blocknova.de` gilt und diese Rechte besitzt:

- Zone → DNS → Read
- Zone → DNS → Edit
- Zone → Zone → Read (wird vom Diagnose-Skript verwendet, um die Zone-ID zu prüfen)

Die Zone-ID von `blocknova.de` findest du in der Cloudflare-Zonenübersicht. Ein HTTP-403 beim Erstellen bedeutet üblicherweise, dass Token, Zone-ID oder die DNS-Read/Edit-Rechte nicht passen. Der Token wird nur auf dem Panelserver gespeichert. Der Code verwendet die Cloudflare DNS API mit Bearer-Token. A-Records werden immer mit `proxied: false` erstellt, da der normale Cloudflare-Webproxy keine direkten Minecraft-TCP-Verbindungen proxyt.

## Installation auf dem Server

Nach dem GitHub-Upload:

```bash
cd /root/Newwww
git pull --ff-only
chmod +x install.sh uninstall.sh reset.sh scripts/*.sh
PTERODACTYL_DIR=/var/www/pterodactyl bash ./install.sh 2>&1 | tee /root/zypehost-install-v21.log
```

Der Installer sichert die vorhandenen Dateien, kopiert Theme und Backend, injiziert den eigenen Subdomain-Tab in die Servernavigation, registriert OAuth-Routen in `routes/auth.php`, registriert die Subdomain-API in `routes/api-client.php`, ergänzt fehlende `.env`-Schlüssel ohne vorhandene Werte zu überschreiben, führt ausschließlich die zwei ZypeHost-Migrationen aus, baut das Frontend und prüft die registrierten Routen.

## `.env` konfigurieren

Der Installer ergänzt diese Schlüssel in `/var/www/pterodactyl/.env`, sofern sie fehlen:

```env
# Cloudflare – Token nur für Zone DNS Edit und nur für blocknova.de
CLOUDFLARE_API_TOKEN=YOUR_CLOUDFLARE_API_TOKEN
CLOUDFLARE_ZONE_ID=YOUR_BLOCKNOVA_DE_ZONE_ID

# Subdomains
ZYPEHOST_SUBDOMAINS_ENABLED=true
ZYPEHOST_SUBDOMAINS_DOMAIN=blocknova.de
ZYPEHOST_SUBDOMAINS_MINECRAFT_ONLY=true
ZYPEHOST_SUBDOMAINS_MAX_PER_SERVER=1

# Optional: kommaseparierte Egg-IDs für exakte Minecraft-Freigabe.
# Wenn leer, prüft das Backend die Egg-/Nest-Namen (Minecraft, Paper, Purpur etc.).
ZYPEHOST_SUBDOMAINS_MINECRAFT_EGG_IDS=

# Optional, falls eine Allocation eine private IP enthält:
# Globale öffentliche IPv4 für alle Nodes:
ZYPEHOST_SUBDOMAINS_PUBLIC_IP=
# Oder je Node: NODE_ID:PUBLIC_IPV4,NODE_ID:PUBLIC_IPV4
ZYPEHOST_SUBDOMAINS_NODE_PUBLIC_IPS=
```

Die Domain ist im Backend fest auf `blocknova.de` gesetzt. Ein vom Browser übermittelter anderer Domainname wird nicht akzeptiert. Der Cloudflare-Proxy bleibt für Spielverkehr aus.

Für Minecraft-Eggs mit ungewöhnlichen Namen empfiehlt sich eine explizite Liste der Egg-IDs. Diese IDs findest du in der Pterodactyl-Datenbank in der Tabelle `eggs`.

Danach die echten Discord-/Google-OAuth-Daten und die Cloudflare-Werte in `.env` eintragen. Cloudflare-Zugang und Zone zuerst prüfen:

```bash
cd /root/Newwww
bash scripts/check-cloudflare.sh /var/www/pterodactyl/.env

cd /var/www/pterodactyl
php artisan optimize:clear
php artisan config:cache
```

## DNS-Verhalten

Für `survival.blocknova.de` wird ein A-Record auf die öffentliche IPv4-Adresse der ausgewählten Allocation erzeugt. Bei Ports ungleich 25565 wird zusätzlich `_minecraft._tcp.survival.blocknova.de` mit dem ausgewählten Port und `survival.blocknova.de` als Ziel angelegt. Das entspricht der Cloudflare-DNS-Record-API für A- und SRV-Records.

Wenn die Allocation eine private Adresse enthält, muss `ZYPEHOST_SUBDOMAINS_PUBLIC_IP` oder `ZYPEHOST_SUBDOMAINS_NODE_PUBLIC_IPS` gesetzt sein. Ohne öffentlich routbare IP wird die Erstellung verweigert, statt einen nicht erreichbaren DNS-Eintrag zu erstellen.

## Prüfen

```bash
cd /var/www/pterodactyl
php artisan route:list --path=zypehost
php artisan route:list --path=zypehost-subdomains
```

Die Subdomain-Endpunkte liegen unter:

- `GET /api/client/servers/{server}/zypehost-subdomains`
- `POST /api/client/servers/{server}/zypehost-subdomains`
- `DELETE /api/client/servers/{server}/zypehost-subdomains/{id}`

Der Live-Test zum Erstellen/Löschen benötigt einen gültigen Cloudflare-Token, die richtige Zone-ID und einen Minecraft-Server mit öffentlicher Allocation. Ein erfolgreicher PHP-/Build-Test ersetzt diesen Cloudflare-Live-Test nicht.

## Deinstallation

```bash
cd /root/Newwww
PTERODACTYL_DIR=/var/www/pterodactyl bash ./uninstall.sh
```

Der Installer stellt Panel-Dateien aus dem Backup wieder her. Die Migrationstabelle und bereits verwaltete Subdomain-Einträge werden nicht automatisch gelöscht, damit beim Entfernen des Themes keine Kundendaten oder DNS-Zuordnungen stillschweigend verloren gehen. DNS-Records bleiben bei Deinstallation bestehen und müssen bei Bedarf zuvor über das Panel entfernt werden.

## Sicherheitshinweise

- `.env`, Cloudflare-Token, OAuth-Secrets und API-Keys nie committen.
- Der Code überschreibt keine bereits vorhandenen DNS-Records; existierende Namen werden abgelehnt.
- DNS-Records werden ausschließlich per gespeicherter Record-ID gelöscht.
- Cloudflare A-Records werden grundsätzlich DNS-only erstellt.
- Nicht-Minecraft-Server werden im Backend abgewiesen, auch wenn jemand den API-Endpunkt manuell aufruft.
- Den Cloudflare-Token auf `blocknova.de` begrenzen und nicht den Global API Key verwenden.

## Paketprüfung

```bash
bash scripts/verify-package.sh
```

Syntaxprüfungen und simulierte Installationsabläufe sind keine Garantie für den produktiven Cloudflare- oder OAuth-Live-Betrieb. Vor dem Einsatz sollte ein Backup der Pterodactyl-Dateien und Datenbank vorliegen.
