<?php

namespace Pterodactyl\Http\Controllers\ZypeHost;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Server;
use Pterodactyl\Services\ZypeHost\CloudflareDnsService;
use RuntimeException;
use Throwable;

class SubdomainController extends Controller
{
    private const DOMAIN = 'blocknova.de';
    private const RESERVED = [
        'www', 'mail', 'smtp', 'imap', 'pop', 'ftp', 'sftp', 'panel', 'admin', 'api',
        'status', 'webmail', 'autodiscover', 'autoconfig', 'ns1', 'ns2', 'cloudflare',
    ];

    public function index(Request $request, $server): JsonResponse
    {
        $server = $this->resolveServer($server);
        $this->assertPermission($server, 'allocation.read');
        $this->assertMinecraft($server);

        $allocations = $this->allocationsFor($server);
        $records = DB::table('zypehost_subdomains')
            ->where('server_id', $server->id)
            ->orderBy('created_at')
            ->get(['id', 'subdomain', 'fqdn', 'allocation_id', 'ip', 'port', 'created_at']);

        return response()->json([
            'eligible' => true,
            'domain' => self::DOMAIN,
            'allocations' => $allocations,
            'subdomains' => $records,
            'limit' => (int) config('zypehost.subdomains.max_per_server', 1),
        ])->header('Cache-Control', 'no-store');
    }

    public function store(Request $request, $server): JsonResponse
    {
        $server = $this->resolveServer($server);
        $this->assertPermission($server, 'allocation.create');
        $this->assertMinecraft($server);

        $validator = Validator::make($request->all(), [
            'subdomain' => ['required', 'string', 'min:2', 'max:48', 'regex:/\A[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\z/'],
            'allocation_id' => ['required', 'integer', 'min:1'],
        ], [
            'subdomain.regex' => 'Erlaubt sind Kleinbuchstaben, Zahlen und Bindestriche. Der Name darf nicht mit einem Bindestrich beginnen oder enden.',
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first(), 'errors' => $validator->errors()], 422);
        }

        $name = strtolower(trim((string) $request->input('subdomain')));
        if (in_array($name, self::RESERVED, true)) {
            return response()->json(['message' => 'Dieser Subdomain-Name ist reserviert.'], 422);
        }

        $limit = max(1, (int) config('zypehost.subdomains.max_per_server', 1));
        if (DB::table('zypehost_subdomains')->where('server_id', $server->id)->count() >= $limit) {
            return response()->json(['message' => 'Für diesen Server ist das Subdomain-Limit erreicht.'], 422);
        }

        $allocation = $this->findAllocation($server, (int) $request->input('allocation_id'));
        if (!$allocation) {
            return response()->json(['message' => 'Die ausgewählte Allocation gehört nicht zu diesem Server.'], 422);
        }

        $ip = $this->publicIpFor($allocation);
        if (!$ip) {
            return response()->json([
                'message' => 'Für diese Allocation wurde keine öffentliche IPv4-Adresse gefunden. Setze ZYPEHOST_SUBDOMAINS_PUBLIC_IP oder ZYPEHOST_SUBDOMAINS_NODE_PUBLIC_IPS in der .env.',
            ], 422);
        }

        $fqdn = $name . '.' . self::DOMAIN;
        $srvName = '_minecraft._tcp.' . $fqdn;
        $comment = 'ZypeHost managed Minecraft server ' . (string) ($server->uuid ?? $server->id);

        try {
            /** @var CloudflareDnsService $cloudflare */
            $cloudflare = app(CloudflareDnsService::class);

            // Never overwrite customer-owned DNS records. Check both the A/CNAME
            // owner name and the Minecraft SRV owner name before creating anything.
            $existingA = $cloudflare->recordsForName($fqdn);
            $existingSrv = $cloudflare->recordsForName($srvName);
            if (count($existingA) > 0 || count($existingSrv) > 0) {
                return response()->json(['message' => 'Diese Subdomain oder ein zugehöriger DNS-Eintrag existiert bereits in Cloudflare.'], 409);
            }

            $aRecord = $cloudflare->createARecord($fqdn, $ip, $comment);
            $srvRecord = null;
            try {
                // SRV is required for a Java client to use a non-default port
                // without typing :port. At 25565, the A record is sufficient.
                if ((int) $allocation->port !== 25565) {
                    $srvRecord = $cloudflare->createMinecraftSrvRecord($fqdn, (int) $allocation->port, $comment);
                }

                $id = DB::table('zypehost_subdomains')->insertGetId([
                    'server_id' => $server->id,
                    'server_identifier' => (string) ($server->identifier ?? $server->uuid),
                    'user_id' => Auth::id(),
                    'allocation_id' => $allocation->id,
                    'subdomain' => $name,
                    'fqdn' => $fqdn,
                    'ip' => $ip,
                    'port' => (int) $allocation->port,
                    'a_record_id' => (string) ($aRecord['id'] ?? ''),
                    'srv_record_id' => (string) ($srvRecord['id'] ?? ''),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            } catch (Throwable $exception) {
                if (!empty($srvRecord['id'])) {
                    try { $cloudflare->deleteRecord((string) $srvRecord['id']); } catch (Throwable $ignored) {}
                }
                if (!empty($aRecord['id'])) {
                    try { $cloudflare->deleteRecord((string) $aRecord['id']); } catch (Throwable $ignored) {}
                }
                throw $exception;
            }

            return response()->json([
                'message' => 'Subdomain wurde erstellt.',
                'subdomain' => DB::table('zypehost_subdomains')->where('id', $id)->first(),
            ], 201);
        } catch (Throwable $exception) {
            Log::error('ZypeHost Cloudflare subdomain creation failed', [
                'server_id' => $server->id,
                'exception' => get_class($exception),
                'message' => $exception->getMessage(),
            ]);
            return response()->json(['message' => $exception->getMessage()], 502);
        }
    }

    public function destroy(Request $request, $server, int $subdomain): JsonResponse
    {
        $server = $this->resolveServer($server);
        $this->assertPermission($server, 'allocation.delete');
        $this->assertMinecraft($server);

        $record = DB::table('zypehost_subdomains')
            ->where('id', $subdomain)
            ->where('server_id', $server->id)
            ->first();

        if (!$record) {
            return response()->json(['message' => 'Subdomain wurde nicht gefunden.'], 404);
        }

        try {
            /** @var CloudflareDnsService $cloudflare */
            $cloudflare = app(CloudflareDnsService::class);
            if (!empty($record->srv_record_id)) {
                $cloudflare->deleteRecord((string) $record->srv_record_id);
            }
            if (!empty($record->a_record_id)) {
                $cloudflare->deleteRecord((string) $record->a_record_id);
            }
            DB::table('zypehost_subdomains')->where('id', $record->id)->delete();

            return response()->json(['message' => 'Subdomain und zugehörige Cloudflare-DNS-Einträge wurden gelöscht.']);
        } catch (Throwable $exception) {
            Log::error('ZypeHost Cloudflare subdomain deletion failed', [
                'server_id' => $server->id,
                'subdomain_id' => $record->id,
                'exception' => get_class($exception),
                'message' => $exception->getMessage(),
            ]);
            return response()->json(['message' => $exception->getMessage()], 502);
        }
    }

    private function resolveServer($routeValue): Server
    {
        if ($routeValue instanceof Server) {
            return $routeValue;
        }

        $value = (string) $routeValue;
        return Server::query()
            ->where('identifier', $value)
            ->orWhere('uuid', $value)
            ->firstOrFail();
    }

    private function assertPermission(Server $server, string $permission): void
    {
        $user = Auth::user();
        if (!$user) {
            abort(401);
        }

        if ((bool) ($user->root_admin ?? false) || (int) $server->owner_id === (int) $user->id) {
            return;
        }

        if (method_exists($server, 'userCan') && $server->userCan($permission)) {
            return;
        }

        abort(403, 'Du hast keine Berechtigung für diese Subdomain-Aktion.');
    }

    private function assertMinecraft(Server $server): void
    {
        if (!(bool) config('zypehost.subdomains.enabled', true)) {
            abort(404);
        }

        $eggIds = config('zypehost.subdomains.minecraft_egg_ids', []);
        if (!empty($eggIds)) {
            if (!in_array((int) $server->egg_id, array_map('intval', $eggIds), true)) {
                abort(response()->json(['code' => 'minecraft_only', 'message' => 'Subdomains sind nur für Minecraft-Server verfügbar.'], 403));
            }
            return;
        }

        $egg = DB::table('eggs')
            ->leftJoin('nests', 'nests.id', '=', 'eggs.nest_id')
            ->where('eggs.id', $server->egg_id)
            ->first(['eggs.name as egg_name', 'nests.name as nest_name']);

        $label = strtolower(trim((string) (($egg->egg_name ?? '') . ' ' . ($egg->nest_name ?? ''))));
        $isMinecraft = preg_match('/minecraft|paper|purpur|spigot|vanilla|fabric|forge|neoforge|folia|velocity|bungeecord/i', $label) === 1;
        if (!$isMinecraft) {
            abort(response()->json(['code' => 'minecraft_only', 'message' => 'Subdomains sind nur für Minecraft-Server verfügbar.'], 403));
        }
    }

    private function allocationsFor(Server $server): array
    {
        $rows = DB::table('allocations as a')
            ->leftJoin('nodes as n', 'n.id', '=', 'a.node_id')
            ->where('a.server_id', $server->id)
            ->orderBy('a.id')
            ->get(['a.id', 'a.ip', 'a.port', 'a.node_id', 'n.fqdn as node_fqdn']);

        $result = [];
        foreach ($rows as $row) {
            $ip = $this->publicIpFor($row);
            if (!$ip) {
                continue;
            }
            $result[] = [
                'id' => (int) $row->id,
                'label' => $ip . ':' . (int) $row->port,
                'ip' => $ip,
                'port' => (int) $row->port,
            ];
        }

        return $result;
    }

    private function findAllocation(Server $server, int $allocationId): ?object
    {
        $row = DB::table('allocations as a')
            ->leftJoin('nodes as n', 'n.id', '=', 'a.node_id')
            ->where('a.server_id', $server->id)
            ->where('a.id', $allocationId)
            ->first(['a.id', 'a.ip', 'a.port', 'a.node_id', 'n.fqdn as node_fqdn']);

        if (!$row) {
            return null;
        }

        $row->public_ip = $this->publicIpFor($row);
        return $row;
    }

    private function publicIpFor(object $allocation): ?string
    {
        $nodeMap = config('zypehost.subdomains.node_public_ips', []);
        $candidate = $nodeMap[(string) ($allocation->node_id ?? '')]
            ?? config('zypehost.subdomains.public_ip')
            ?? null;

        if (!$candidate && isset($allocation->ip) && filter_var($allocation->ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $candidate = $allocation->ip;
        }
        if (!$candidate && isset($allocation->node_fqdn) && filter_var($allocation->node_fqdn, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $candidate = $allocation->node_fqdn;
        }

        if (!$candidate || !filter_var($candidate, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            return null;
        }

        // Cloudflare A records need a publicly routable address. Private and
        // reserved addresses are not valid targets for players on the Internet.
        if (!filter_var($candidate, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            return null;
        }

        return $candidate;
    }
}
