#!/usr/bin/env bash
# ZypeHost Pterodactyl Theme v21 — installer
# v19: portable GitHub-root package, installs OAuth via routes/auth.php, no remote image dependency.
# v20 added Minecraft-only Cloudflare subdomains; v21 adds the missing server-navigation tab.
# v10 adds: swapped login card layout (form left / logo right), a real
# Impressum instead of placeholders, a redesigned brand mark, and a new
# "Z" favicon set that replaces Pterodactyl's default falcon favicon.
set -Eeuo pipefail

PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SRC="$ROOT_DIR/theme/public/themes/zypehost"
FAVICON_SRC="$ROOT_DIR/theme/public/favicons"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$PANEL_DIR/storage/zypehost-backups/v21-$STAMP"
TARGET="$PANEL_DIR/resources/scripts/components/auth/LoginFormContainer.tsx"
WRAPPER="$PANEL_DIR/resources/views/templates/wrapper.blade.php"
ASSET_DIR="$PANEL_DIR/public/themes/zypehost"
FAVICON_DIR="$PANEL_DIR/public/favicons"
AUTH_ROUTES="$PANEL_DIR/routes/auth.php"
API_CLIENT_ROUTES="$PANEL_DIR/routes/api-client.php"
WEB_ROUTES="$PANEL_DIR/routes/web.php"

fail(){ echo "[ZypeHost v21] ERROR: $*" >&2; exit 1; }
info(){ echo "[ZypeHost v21] $*"; }

[[ -f "$PANEL_DIR/artisan" ]] || fail "Pterodactyl nicht gefunden: $PANEL_DIR"
[[ -f "$PANEL_DIR/.env" ]] || fail "Panel-.env nicht gefunden: $PANEL_DIR/.env"
[[ -f "$PANEL_DIR/vendor/autoload.php" ]] || fail "Composer-Abhängigkeiten fehlen: vendor/autoload.php nicht gefunden."
[[ -f "$TARGET" ]] || fail "LoginFormContainer.tsx nicht gefunden: $TARGET"
[[ -f "$WRAPPER" ]] || fail "wrapper.blade.php nicht gefunden: $WRAPPER"
[[ -f "$AUTH_ROUTES" ]] || fail "routes/auth.php nicht gefunden: $AUTH_ROUTES"
[[ -f "$API_CLIENT_ROUTES" ]] || fail "routes/api-client.php nicht gefunden: $API_CLIENT_ROUTES"
command -v php >/dev/null 2>&1 || fail "PHP CLI wurde nicht gefunden."
command -v python3 >/dev/null 2>&1 || fail "python3 wurde nicht gefunden."
command -v node >/dev/null 2>&1 || fail "Node.js wurde nicht gefunden."
if command -v yarn >/dev/null 2>&1; then
    BUILD_TOOL="yarn"
elif command -v npm >/dev/null 2>&1; then
    BUILD_TOOL="npm"
else
    fail "Weder Yarn noch npm gefunden; Frontend kann nicht gebaut werden."
fi
node -e "const p=require('$PANEL_DIR/package.json'); if (!p.scripts || !p.scripts['build:production']) process.exit(1)" 2>/dev/null || fail "package.json enthält kein build:production-Script."
[[ -f "$ROOT_DIR/backend/controllers/OAuthController.php" ]] || fail "OAuthController.php fehlt im ZIP"
[[ -f "$ROOT_DIR/backend/routes/zypehost-oauth.php" ]] || fail "OAuth-Routen fehlen im ZIP"
[[ -f "$ROOT_DIR/backend/migrations/2026_10_31_000000_create_zypehost_oauth_accounts_table.php" ]] || fail "OAuth-Migration fehlt im ZIP"
[[ -f "$ROOT_DIR/backend/config/zypehost.php" ]] || fail "ZypeHost-Konfiguration fehlt im ZIP"
[[ -f "$ROOT_DIR/backend/controllers/SubdomainController.php" ]] || fail "SubdomainController.php fehlt im ZIP"
[[ -f "$ROOT_DIR/backend/services/CloudflareDnsService.php" ]] || fail "CloudflareDnsService.php fehlt im ZIP"
[[ -f "$ROOT_DIR/backend/routes/zypehost-subdomains-api.php" ]] || fail "Subdomain-API-Routen fehlen im ZIP"
[[ -f "$ROOT_DIR/backend/routes/zypehost-subdomains.php" ]] || fail "Subdomain-Routen fehlen im ZIP"
[[ -f "$ROOT_DIR/backend/migrations/2026_11_03_000000_create_zypehost_subdomains_table.php" ]] || fail "Subdomain-Migration fehlt im ZIP"
[[ -f "$SRC/subdomains.js" ]] || fail "Subdomain-Frontend fehlt im ZIP"
grep -q "ensureSubdomainTab" "$SRC/subdomains.js" || fail "Subdomain-Frontend enthält keine eigene Navigationseinbindung."
[[ -f "$SRC/background.jpeg" ]] || fail "background.jpeg fehlt im Theme-Ordner"
[[ -f "$SRC/zypehost-logo.png" ]] || fail "zypehost-logo.png fehlt im Theme-Ordner"
[[ -f "$SRC/zypehost-icon.png" ]] || fail "zypehost-icon.png fehlt im Theme-Ordner"
[[ -f "$SRC/dashboard-bg.jpg" ]] || fail "dashboard-bg.jpg fehlt im Theme-Ordner"
[[ -d "$FAVICON_SRC" ]] || fail "favicons-Ordner fehlt im Theme-Ordner"

mkdir -p "$PANEL_DIR/storage/zypehost-backups" "$BACKUP"
chmod 700 "$PANEL_DIR/storage/zypehost-backups" "$BACKUP"
# Keep the first pre-theme backup as the rollback baseline across repeated
# v20/v21 updates. Otherwise uninstall after an update would restore a prior
# ZypeHost theme instead of the files that were present before the first theme install.
BASELINE_BACKUP="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v20-*' ! -path "$BACKUP" 2>/dev/null | sort | head -n1 || true)"
if [[ -z "$BASELINE_BACKUP" ]]; then BASELINE_BACKUP="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v19-*' 2>/dev/null | sort | head -n1 || true)"; fi
if [[ -n "$BASELINE_BACKUP" && -f "$BASELINE_BACKUP/LoginFormContainer.tsx" ]]; then
    cp -a "$BASELINE_BACKUP/." "$BACKUP/"
    info "Ursprüngliches Backup von $BASELINE_BACKUP als Rollback-Basis übernommen."
else
    cp -a "$TARGET" "$BACKUP/LoginFormContainer.tsx"
    [[ -f "$WRAPPER" ]] && cp -a "$WRAPPER" "$BACKUP/wrapper.blade.php" || true
    [[ -d "$FAVICON_DIR" ]] && cp -a "$FAVICON_DIR" "$BACKUP/favicons" || true
    [[ -f "$PANEL_DIR/.env" ]] && cp -a "$PANEL_DIR/.env" "$BACKUP/.env" || true
    if [[ -d "$ASSET_DIR" ]]; then cp -a "$ASSET_DIR" "$BACKUP/zypehost-assets"; else touch "$BACKUP/no-previous-assets"; fi
    if [[ -f "$PANEL_DIR/public/favicon.ico" ]]; then cp -a "$PANEL_DIR/public/favicon.ico" "$BACKUP/public-favicon.ico"; else touch "$BACKUP/no-previous-public-favicon"; fi
    [[ -f "$PANEL_DIR/routes/zypehost-oauth.php" ]] && cp -a "$PANEL_DIR/routes/zypehost-oauth.php" "$BACKUP/zypehost-oauth.php" || true
    [[ -f "$AUTH_ROUTES" ]] && cp -a "$AUTH_ROUTES" "$BACKUP/auth.php" || true
    [[ -f "$PANEL_DIR/database/migrations/2026_10_31_000000_create_zypehost_oauth_accounts_table.php" ]] && cp -a "$PANEL_DIR/database/migrations/2026_10_31_000000_create_zypehost_oauth_accounts_table.php" "$BACKUP/oauth-migration.php" || true
    [[ -f "$PANEL_DIR/config/zypehost.php" ]] && cp -a "$PANEL_DIR/config/zypehost.php" "$BACKUP/zypehost.php" || true
    [[ -f "$PANEL_DIR/app/Http/Controllers/ZypeHost/OAuthController.php" ]] && cp -a "$PANEL_DIR/app/Http/Controllers/ZypeHost/OAuthController.php" "$BACKUP/OAuthController.php" || true
    # If this panel was already modified by an older pre-v19 installer, remove
    # only its tagged OAuth include from the saved auth.php snapshot.
    if [[ -f "$BACKUP/auth.php" ]]; then
        python3 - "$BACKUP/auth.php" <<'PYBACKUP'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
s = re.sub(r'(?m)^.*ZYPEHOST_OAUTH_ROUTE_REGISTRATION.*\n?', '', s)
s = re.sub(r"(?m)^.*require_once __DIR__\s*\.\s*['\"]/zypehost-oauth\.php['\"];?.*\n?", '', s)
p.write_text(s, encoding='utf-8')
PYBACKUP
    fi
fi
# v20/v21 also change api-client.php and install backend files. Preserve
# their pre-v20 state even when the baseline backup was created by v19.
if [[ -f "$API_CLIENT_ROUTES" && ! -f "$BACKUP/api-client.php" ]]; then cp -a "$API_CLIENT_ROUTES" "$BACKUP/api-client.php"; fi
for ITEM in \
    "$PANEL_DIR/app/Http/Controllers/ZypeHost/SubdomainController.php:SubdomainController.php" \
    "$PANEL_DIR/app/Services/ZypeHost/CloudflareDnsService.php:CloudflareDnsService.php" \
    "$PANEL_DIR/routes/zypehost-subdomains-api.php:zypehost-subdomains-api.php" \
    "$PANEL_DIR/routes/zypehost-subdomains.php:zypehost-subdomains.php" \
    "$PANEL_DIR/database/migrations/2026_11_03_000000_create_zypehost_subdomains_table.php:subdomains-migration.php"; do
    SOURCE_PATH="${ITEM%%:*}"
    BACKUP_NAME="${ITEM#*:}"
    ABSENT_MARKER="$BACKUP/no-original-$BACKUP_NAME"
    if [[ -f "$SOURCE_PATH" && ! -f "$BACKUP/$BACKUP_NAME" && ! -f "$ABSENT_MARKER" ]]; then
        cp -a "$SOURCE_PATH" "$BACKUP/$BACKUP_NAME"
    elif [[ ! -f "$SOURCE_PATH" && ! -f "$BACKUP/$BACKUP_NAME" ]]; then
        touch "$ABSENT_MARKER"
    fi
done
# Backups contain the original panel .env (database credentials and API keys).
# Keep those credentials readable only by root.
[[ -f "$BACKUP/.env" ]] && chmod 600 "$BACKUP/.env"
chmod 700 "$BACKUP"
info "Backup gespeichert unter: $BACKUP"

# --- Step 1: remove only known old ZypeHost wrapper markers ---------------
# Never run `git checkout` against a live panel: it could discard unrelated
# administrator edits. Keep all non-ZypeHost edits untouched.
cd "$PANEL_DIR"
if [[ -f "$WRAPPER" ]]; then
    info "Entferne alte ZypeHost-Marker aus wrapper.blade.php (andere Änderungen bleiben erhalten)..."
    python3 - "$WRAPPER" <<'PYMARK'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
for marker in ('ZYPEHOST_V6_ASSETS', 'ZYPEHOST_V5_ASSETS', 'ZYPEHOST_V4_ASSETS', 'ZYPEHOST_V3_ASSETS', 'ZYPEHOST_V2_ASSETS'):
    s = re.sub(r'<!--\s*' + re.escape(marker) + r'\s*-->.*?<!--\s*/' + re.escape(marker) + r'\s*-->\s*', '', s, flags=re.S)
s = re.sub(r'<!--[^>]*zypehost[^>]*-->.*?<!--[^>]*/[^>]*zypehost[^>]*-->\s*', '', s, flags=re.S | re.I)
p.write_text(s, encoding='utf-8')
PYMARK
fi

# --- Step 2: wipe old theme assets completely, then lay down fresh ones ---
rm -rf "$ASSET_DIR"
mkdir -p "$ASSET_DIR"
cp -f "$SRC/background.jpeg" "$ASSET_DIR/background.jpeg"
cp -f "$SRC/zypehost-logo.png" "$ASSET_DIR/zypehost-logo.png"
cp -f "$SRC/zypehost-icon.png" "$ASSET_DIR/zypehost-icon.png"
cp -f "$SRC/dashboard-bg.jpg" "$ASSET_DIR/dashboard-bg.jpg"
cp -f "$SRC/subdomains.js" "$ASSET_DIR/subdomains.js"
# Dashboard background is shipped inside this ZIP; installation has no dependency
# on a public GitHub raw URL or an external image download.

# --- Step 3: write the new single-card component (full overwrite) --------
cp -f "$ROOT_DIR/theme/LoginFormContainer.tsx" "$TARGET"

# --- Step 3b: replace the default Pterodactyl favicon with the ZypeHost
#     "Z" mark (same filenames, so no blade/template edits are needed) ----
mkdir -p "$FAVICON_DIR"
# Overwrite EVERY icon file Pterodactyl's default favicon set ships with
# (android-icon-*, apple-icon-*, ms-icon-*, mstile-*, favicon-96x96, the
# favicon.ico that lives inside public/favicons/, plus the Safari pinned-tab
# SVG) so no old falcon file can survive in any size/format a browser might
# prefer over the ones we already knew about.
cp -f "$FAVICON_SRC"/*.png "$FAVICON_DIR/" 2>/dev/null || true
cp -f "$FAVICON_SRC"/*.svg "$FAVICON_DIR/" 2>/dev/null || true
cp -f "$FAVICON_SRC/favicon.ico" "$FAVICON_DIR/favicon.ico" 2>/dev/null || true
cp -f "$FAVICON_SRC/favicon.ico" "$PANEL_DIR/public/favicon.ico" 2>/dev/null || true
info "Favicon ersetzt (Falke -> Z), komplettes Set inkl. Apple/Android/MS-Icons und Safari-Pinned-Tab."

# --- Step 3c: force browsers to actually fetch the new favicons -----------
# Pterodactyl's default wrapper.blade.php links to /favicons/... with no
# cache-busting query string at all, so browsers that already cached the
# old falcon icons keep showing them forever even though the files on disk
# are correct. Fix: append/refresh a "?v=<timestamp>" query on every
# favicon-related href/content in wrapper.blade.php so each install forces
# a guaranteed-fresh fetch, independent of any browser cache.
if [[ -f "$WRAPPER" ]]; then
    FAVICON_STAMP="$STAMP" python3 - "$WRAPPER" <<'PY'
from pathlib import Path
import os, re, sys

p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
stamp = os.environ['FAVICON_STAMP']

def bust(match):
    attr, path = match.group(1), match.group(2)
    path = re.sub(r'\?v=[^"\']*', '', path)  # drop any previous cache-buster
    return f'{attr}="{path}?v={stamp}"'

# Matches href="/favicons/..." and content="/favicons/..." (browserconfig meta)
s = re.sub(r'(href|content)="(/favicons/[^"]*)"', bust, s)
p.write_text(s, encoding='utf-8')
PY
    info "Cache-Buster auf Favicon-Links in wrapper.blade.php gesetzt (?v=$STAMP) — Browser MUSS neu laden."

    # --- Step 3d: dashboard-only background (never on the login screen) --
    # wrapper.blade.php already knows whether someone is logged in — it uses
    # Auth::user() further down to decide whether to print window.PterodactylUser.
    # We reuse that exact same check on the <body> tag: only when the user IS
    # authenticated (dashboard / server pages) do we add a class that paints
    # the new background. The login/forgot-password/reset screens run through
    # AuthenticationRouter with no authenticated user, so Auth::user() is null
    # there and the class — and therefore the image — never appears.
    python3 - "$WRAPPER" "$STAMP" <<'PY'
from pathlib import Path
import re, sys

p = Path(sys.argv[1])
stamp = sys.argv[2]
s = p.read_text(encoding='utf-8')

body_tag_match = re.search(r'<body[^>]*>', s)
already_patched = bool(body_tag_match) and 'zypehost-dashboard-bg' in body_tag_match.group(0)

body_re = re.compile(r'<body class="\{\{\s*\$css\[\'body\'\]\s*\?\?\s*\'([^\']*)\'\s*\}\}">')
if already_patched:
    pass  # already patched by a previous install run, leave the <body> tag alone
elif body_re.search(s):
    s = body_re.sub(
        lambda m: (
            '<body class="{{ $css[\'body\'] ?? \'' + m.group(1) + '\' }}'
            ' @if(!is_null(Auth::user())) zypehost-dashboard-bg @endif">'
        ),
        s,
        count=1,
    )
else:
    # Fallback: whatever the body tag looks like, just tack the same
    # conditional class onto it so this still works on unexpected markup.
    s = re.sub(
        r'<body class="([^"]*)">',
        lambda m: f'<body class="{m.group(1)} @if(!is_null(Auth::user())) zypehost-dashboard-bg @endif">',
        s,
        count=1,
    )

css_block = (
    "<style>\n"
    ".zypehost-dashboard-bg {\n"
    "  background:\n"
    "    linear-gradient(rgba(8,12,18,.55), rgba(8,12,18,.72)),\n"
    "    url(\'/themes/zypehost/dashboard-bg.jpg\') center center / cover no-repeat fixed !important;\n"
    "}\n"
    "/* Pterodactyl's panels/cards use Tailwind colour utilities, which are\n"
    "   fully opaque by default and completely cover any body background.\n"
    "   Tailwind's color utilities read their alpha from the --tw-bg-opacity\n"
    "   custom property, so lowering it (instead of guessing exact class\n"
    "   names, which change between panel versions) lets the new background\n"
    "   image show through everywhere at once. Modals/popups are kept solid\n"
    "   via #modal-portal so dialogs stay easy to read. */\n"
    ".zypehost-dashboard-bg * {\n"
    "  --tw-bg-opacity: 0.55 !important;\n"
    "}\n"
    ".zypehost-dashboard-bg #modal-portal *,\n"
    ".zypehost-dashboard-bg [role='dialog'] * {\n"
    "  --tw-bg-opacity: 0.94 !important;\n"
    "}\n"
    "/* Nicer buttons + server-list rows, panel-version independent (no core\n"
    "   TSX files touched, so this survives Pterodactyl updates). */\n"
    "button, a[href^='/server/'] {\n"
    "  transition: transform .12s ease, filter .12s ease, box-shadow .12s ease !important;\n"
    "}\n"
    "button:hover {\n"
    "  filter: brightness(1.12);\n"
    "  transform: translateY(-1px);\n"
    "}\n"
    "button:active {\n"
    "  transform: translateY(0);\n"
    "  filter: brightness(0.96);\n"
    "}\n"
    "a[href^='/server/'] {\n"
    "  border-radius: 0.75rem !important;\n"
    "  overflow: hidden;\n"
    "}\n"
    "a[href^='/server/']:hover {\n"
    "  transform: translateY(-2px);\n"
    "  box-shadow: 0 10px 24px rgba(0,0,0,.35) !important;\n"
    "}\n"
    "</style>\n"
)
if '.zypehost-dashboard-bg {' not in s:
    s = s.replace('</head>', css_block + '</head>')
else:
    s = re.sub(r"<style>\n\.zypehost-dashboard-bg.*?</style>\n", css_block, s, flags=re.S)

# --- Step 3e: rebrand the built-in "Pterodactyl® © 2015 - <year>" footer -
# That footer text lives inside Pterodactyl's own React components (not
# something this theme ships/overwrites), and its exact file/markup shifts
# between panel versions. Instead of guessing the source file, a small,
# self-contained script finds that exact text wherever it renders and swaps
# only the "Pterodactyl(R)" part for "ZypeHost", leaving "(c) 2015 - year"
# intact. Wrapped in a marker so re-running install.sh never duplicates it.
footer_marker_open = '<!-- ZYPEHOST_FOOTER_BRAND -->'
footer_marker_close = '<!-- /ZYPEHOST_FOOTER_BRAND -->'
s = re.sub(
    re.escape(footer_marker_open) + r'.*?' + re.escape(footer_marker_close) + r'\s*',
    '',
    s,
    flags=re.S,
)
footer_script = (
    footer_marker_open + "\n"
    "<script>\n"
    "(function () {\n"
    "  function rebrandText() {\n"
    "    var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);\n"
    "    var node;\n"
    "    while ((node = walker.nextNode())) {\n"
    "      if (node.nodeValue.indexOf('Pterodactyl') !== -1) {\n"
    "        node.nodeValue = node.nodeValue.replace(/Pterodactyl\\u00AE?/g, 'ZypeHost');\n"
    "      }\n"
    "    }\n"
    "  }\n"
    "  // The dashboard's big page-level wrapper divs are fully opaque, no\n"
    "  // matter what colour utility framework built them, so a background\n"
    "  // set on <body> alone never shows through. Rather than guess exact\n"
    "  // class names (which differ between panel versions), read each large\n"
    "  // element's REAL computed background colour at runtime and only make\n"
    "  // the big, dark, fully-opaque wrapper elements translucent — small\n"
    "  // elements (buttons, badges, status pills) and light/white elements\n"
    "  // (modal cards, the login form) are left completely alone.\n"
    "  function ghostBigBackgrounds() {\n"
    "    if (!document.body.classList.contains('zypehost-dashboard-bg')) return;\n"
    "    var vh = window.innerHeight, vw = window.innerWidth;\n"
    "    var els = document.querySelectorAll('#app, #app *');\n"
    "    for (var i = 0; i < els.length; i++) {\n"
    "      var el = els[i];\n"
    "      if (el.dataset.zypehostGhosted === '1') continue;\n"
    "      var rect = el.getBoundingClientRect();\n"
    "      if (rect.width < vw * 0.6 || rect.height < vh * 0.35) continue;\n"
    "      var cs = getComputedStyle(el);\n"
    "      var m = cs.backgroundColor && cs.backgroundColor.match(/rgba?\\(([\\d.]+),\\s*([\\d.]+),\\s*([\\d.]+)(?:,\\s*([\\d.]+))?\\)/);\n"
    "      if (!m) continue;\n"
    "      var r = +m[1], g = +m[2], b = +m[3];\n"
    "      var a = m[4] !== undefined ? parseFloat(m[4]) : 1;\n"
    "      if (a < 0.85) continue;\n"
    "      if ((r + g + b) > 380) continue;\n"
    "      el.style.setProperty('background-color', 'rgba(' + r + ',' + g + ',' + b + ',0.32)', 'important');\n"
    "      el.dataset.zypehostGhosted = '1';\n"
    "    }\n"
    "  }\n"
    "  function runAll() { rebrandText(); ghostBigBackgrounds(); }\n"

    "  // Debounced: the server console streams log lines into the DOM\n"
    "  // constantly, so an observer callback that runs on every single\n"
    "  // mutation would re-scan the whole page far too often. Collapse\n"
    "  // bursts down to at most one scan per second instead.\n"
    "  var pending = null;\n"
    "  function scheduleRun() {\n"
    "    if (pending) return;\n"
    "    pending = setTimeout(function () { pending = null; runAll(); }, 1000);\n"
    "  }\n"
    "  document.addEventListener('DOMContentLoaded', function () {\n"
    "    runAll();\n"
    "    setTimeout(runAll, 800);\n"
    "    new MutationObserver(scheduleRun).observe(document.body, { childList: true, subtree: true });\n"
    "  });\n"
    "})();\n"
    "</script>\n"
    + footer_marker_close + "\n"
)
s = s.replace('</body>', footer_script + '</body>')

# Load the self-contained Minecraft-only subdomain UI on server pages. v21
# injects its own navigation item beside Network; no existing plugin/tab is
# required. The custom URL is handled by the overlay without changing React routes.
subdomain_marker_open = '<!-- ZYPEHOST_SUBDOMAIN_UI -->'
subdomain_marker_close = '<!-- /ZYPEHOST_SUBDOMAIN_UI -->'
s = re.sub(re.escape(subdomain_marker_open) + r'.*?' + re.escape(subdomain_marker_close) + r'\s*', '', s, flags=re.S)
subdomain_tag = (subdomain_marker_open + '\n' +
    '<script src="/themes/zypehost/subdomains.js?v=' + stamp + '" defer></script>\n' +
    subdomain_marker_close + '\n')
if '</body>' not in s:
    raise SystemExit('wrapper.blade.php enthält kein </body>; Subdomain-UI kann nicht geladen werden')
s = s.replace('</body>', subdomain_tag + '</body>')

# Remove any widget left by earlier theme versions; v15 installs no support/admin widget.
for marker in ('ZYPEHOST_SUPPORT_WIDGET', 'ZYPEHOST_ADMIN_ACCESS_WIDGET'):
    s = re.sub(r'<!--\s*' + marker + r'\s*-->.*?<!--\s*/' + marker + r'\s*-->\s*', '', s, flags=re.S)
p.write_text(s, encoding='utf-8')
PY
    info "Dashboard-Hintergrund (Schnee-Bild) eingebaut — nur sichtbar nach dem Login, Login-Seite bleibt unveraendert."
    info "Footer-Branding aktiv: 'Pterodactyl(R)' im Copyright wird automatisch zu 'ZypeHost'."
    info "Minecraft-Subdomain-UI wird geladen; der Subdomain-Tab wird für Minecraft-Server automatisch in die Servernavigation eingefügt."
else
    info "Hinweis: wrapper.blade.php nicht gefunden, Cache-Buster/Dashboard-Hintergrund-Schritt übersprungen."
fi

# --- Step 3f: remove the former customer-server access feature completely ---
# Clean the Blade wrapper (including any old widget copied by earlier versions).
if [[ -f "$WRAPPER" ]]; then
    python3 - "$WRAPPER" <<'PYIN'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
for marker in ('ZYPEHOST_ADMIN_ACCESS_WIDGET', 'ZYPEHOST_SUPPORT_WIDGET'):
    s = re.sub(r'<!--\s*' + marker + r'\s*-->.*?<!--\s*/' + marker + r'\s*-->\s*', '', s, flags=re.S)
p.write_text(s, encoding='utf-8')
PYIN
fi

# Remove route registration and backend files from previous v12-v14 installs.
# Remove stale legacy registrations without assuming this Panel has routes/web.php.
for ROUTE_FILE in "$AUTH_ROUTES" "$WEB_ROUTES"; do
    if [[ -f "$ROUTE_FILE" ]]; then
        python3 - "$ROUTE_FILE" <<'PYIN'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
s = re.sub(r'(?m)^.*ZypeHost: email-confirmed admin access.*\n?', '', s)
s = re.sub(r'(?m)^.*routes/zypehost-admin-access\.php.*\n?', '', s)
s = re.sub(r'(?m)^.*ZypeHost: support-login.*\n?', '', s)
s = re.sub(r'(?m)^.*routes/zypehost-support\.php.*\n?', '', s)
# Remove any stale OAuth include; it is re-added exactly once below.
s = re.sub(r'(?m)^.*ZYPEHOST_OAUTH_ROUTE_REGISTRATION.*\n?', '', s)
s = re.sub(r"(?m)^.*require_once __DIR__\s*\.\s*['\"]/zypehost-oauth\.php['\"];?.*\n?", '', s)
p.write_text(s, encoding='utf-8')
PYIN
    fi
done
rm -f "$PANEL_DIR/routes/zypehost-admin-access.php"
rm -f "$PANEL_DIR/routes/zypehost-support.php"
rm -f "$PANEL_DIR/app/Http/Controllers/ZypeHost/AdminAccessController.php"
rm -f "$PANEL_DIR/app/Http/Controllers/ZypeHost/SupportLoginController.php"
rm -f "$PANEL_DIR/app/Console/Commands/ZypeHostSupportPin.php"
# If the former Support-PIN migration never ran, remove it so it cannot
# add an unused column during a later manual migration. Applied migrations stay intact.
OLD_PIN_MIGRATION="$PANEL_DIR/database/migrations/2026_09_23_000000_add_support_pin_to_users_table.php"
if [[ -f "$OLD_PIN_MIGRATION" ]]; then
    OLD_PIN_STATUS="$(php artisan migrate:status --no-ansi 2>/dev/null | grep '2026_09_23_000000_add_support_pin_to_users_table' || true)"
    if [[ "$OLD_PIN_STATUS" == *"| No "* || "$OLD_PIN_STATUS" == *"|No "* ]]; then
        rm -f "$OLD_PIN_MIGRATION"
    fi
fi
rmdir "$PANEL_DIR/app/Http/Controllers/ZypeHost" 2>/dev/null || true
info "Kundenserver-Button und E-Mail-Code-Funktion vollständig entfernt."

# --- Step 3g: install Discord + Google OAuth backend ----------------------
info "Installiere ZypeHost OAuth-Backend (Discord + Google)..."
mkdir -p "$PANEL_DIR/app/Http/Controllers/ZypeHost" "$PANEL_DIR/routes" "$PANEL_DIR/config"
cp -f "$ROOT_DIR/backend/controllers/OAuthController.php" "$PANEL_DIR/app/Http/Controllers/ZypeHost/OAuthController.php"
cp -f "$ROOT_DIR/backend/routes/zypehost-oauth.php" "$PANEL_DIR/routes/zypehost-oauth.php"
cp -f "$ROOT_DIR/backend/config/zypehost.php" "$PANEL_DIR/config/zypehost.php"
cp -f "$ROOT_DIR/backend/migrations/2026_10_31_000000_create_zypehost_oauth_accounts_table.php" "$PANEL_DIR/database/migrations/2026_10_31_000000_create_zypehost_oauth_accounts_table.php"
python3 - "$AUTH_ROUTES" <<'PYIN'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
marker = "// ZYPEHOST_OAUTH_ROUTE_REGISTRATION"
line = "require_once __DIR__ . '/zypehost-oauth.php';"
# Make repeated installs idempotent, and put the include BEFORE Laravel's
# catch-all fallback (Pterodactyl's standard auth.php registers one last).
s = re.sub(r"(?m)^\s*// ZYPEHOST_OAUTH_ROUTE_REGISTRATION\s*\n", "", s)
s = re.sub(r"(?m)^\s*require_once __DIR__\s*\.\s*['\"]/zypehost-oauth\.php['\"];?\s*\n?", "", s)
block = marker + "\n" + line + "\n\n"
match = re.search(r"(?m)^\s*Route::fallback\s*\(", s)
if match:
    s = s[:match.start()] + block + s[match.start():]
else:
    s = s.rstrip()
    if s.endswith('?>'):
        s = s[:-2].rstrip()
    s += "\n\n" + block
p.write_text(s, encoding='utf-8')
PYIN
info "OAuth-Routen in routes/auth.php registriert (Pterodactyl /auth-Gruppe)."
grep -q "zypehost-oauth.php" "$AUTH_ROUTES" || fail "OAuth-Routen konnten nicht in routes/auth.php registriert werden."
python3 - "$AUTH_ROUTES" <<'PYROUTE'
from pathlib import Path
import re, sys
s = Path(sys.argv[1]).read_text(encoding='utf-8')
include = s.find("require_once __DIR__ . '/zypehost-oauth.php';")
fallback = re.search(r"(?m)^\s*Route::fallback\s*\(", s)
if include < 0:
    raise SystemExit('OAuth include fehlt')
if fallback and include > fallback.start():
    raise SystemExit('OAuth include steht hinter Route::fallback')
PYROUTE

# --- Step 3h: install Minecraft-only Cloudflare subdomain backend ---------
info "Installiere Minecraft-only Subdomains für blocknova.de..."
mkdir -p "$PANEL_DIR/app/Http/Controllers/ZypeHost" "$PANEL_DIR/app/Services/ZypeHost" "$PANEL_DIR/routes"
cp -f "$ROOT_DIR/backend/controllers/SubdomainController.php" "$PANEL_DIR/app/Http/Controllers/ZypeHost/SubdomainController.php"
cp -f "$ROOT_DIR/backend/services/CloudflareDnsService.php" "$PANEL_DIR/app/Services/ZypeHost/CloudflareDnsService.php"
cp -f "$ROOT_DIR/backend/routes/zypehost-subdomains-api.php" "$PANEL_DIR/routes/zypehost-subdomains-api.php"
cp -f "$ROOT_DIR/backend/routes/zypehost-subdomains.php" "$PANEL_DIR/routes/zypehost-subdomains.php"
cp -f "$ROOT_DIR/backend/migrations/2026_11_03_000000_create_zypehost_subdomains_table.php" "$PANEL_DIR/database/migrations/2026_11_03_000000_create_zypehost_subdomains_table.php"
python3 - "$API_CLIENT_ROUTES" <<'PYAPI'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
start = "// ZYPEHOST_SUBDOMAIN_ROUTE_REGISTRATION_START"
end = "// ZYPEHOST_SUBDOMAIN_ROUTE_REGISTRATION_END"
s = re.sub(re.escape(start) + r".*?" + re.escape(end) + r"\s*", "", s, flags=re.S)
block = (start + "\n" +
         "require_once __DIR__ . '/zypehost-subdomains-api.php';\n" +
         end + "\n")
s = s.rstrip() + "\n\n" + block
p.write_text(s, encoding='utf-8')
PYAPI
php -l "$API_CLIENT_ROUTES" >/dev/null || fail "routes/api-client.php hat nach dem Einfügen einen Syntaxfehler."
php -l "$PANEL_DIR/app/Http/Controllers/ZypeHost/SubdomainController.php" >/dev/null || fail "SubdomainController hat einen PHP-Syntaxfehler."
php -l "$PANEL_DIR/app/Services/ZypeHost/CloudflareDnsService.php" >/dev/null || fail "CloudflareDnsService hat einen PHP-Syntaxfehler."
php -l "$PANEL_DIR/routes/zypehost-subdomains-api.php" >/dev/null || fail "Subdomain-API-Routen haben einen PHP-Syntaxfehler."

# Add only missing configuration keys. Existing values (including real secrets)
# are never overwritten. Placeholder secrets must be replaced before OAuth use.
info "Ergänze fehlende ZypeHost-Einstellungen in der Panel-.env..."
python3 - "$PANEL_DIR/.env" <<'PYENV'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
defaults = {
    "ZYPEHOST_OAUTH_DISCORD_CLIENT_ID": "YOUR_DISCORD_APPLICATION_CLIENT_ID",
    "ZYPEHOST_OAUTH_DISCORD_CLIENT_SECRET": "YOUR_DISCORD_CLIENT_SECRET",
    "ZYPEHOST_OAUTH_DISCORD_REDIRECT_URI": "https://panel.blocknova.de/auth/zypehost/discord/callback",
    "ZYPEHOST_OAUTH_GOOGLE_CLIENT_ID": "YOUR_GOOGLE_OAUTH_CLIENT_ID",
    "ZYPEHOST_OAUTH_GOOGLE_CLIENT_SECRET": "YOUR_GOOGLE_CLIENT_SECRET",
    "ZYPEHOST_OAUTH_GOOGLE_REDIRECT_URI": "https://panel.blocknova.de/auth/zypehost/google/callback",
    "ZYPEHOST_OAUTH_AUTO_REGISTER": "true",
    "ZYPEHOST_OAUTH_LINK_EXISTING_EMAIL": "true",
    "ZYPEHOST_OAUTH_ALLOWED_DOMAINS": "",
    "ZYPEHOST_API_URL": "https://zypehost.blocknova.de/api/v1/admin",
    "ZYPEHOST_API_KEY": "YOUR_ZYPEHOST_ADMIN_API_KEY",
    "ZYPEHOST_API_KEY_HEADER": "Authorization",
    "ZYPEHOST_API_KEY_PREFIX": "Bearer",
    "CLOUDFLARE_API_TOKEN": "YOUR_CLOUDFLARE_API_TOKEN",
    "CLOUDFLARE_ZONE_ID": "YOUR_BLOCKNOVA_DE_ZONE_ID",
    "ZYPEHOST_SUBDOMAINS_ENABLED": "true",
    "ZYPEHOST_SUBDOMAINS_DOMAIN": "blocknova.de",
    "ZYPEHOST_SUBDOMAINS_MINECRAFT_ONLY": "true",
    "ZYPEHOST_SUBDOMAINS_MAX_PER_SERVER": "1",
    "ZYPEHOST_SUBDOMAINS_MINECRAFT_EGG_IDS": "",
    "ZYPEHOST_SUBDOMAINS_PUBLIC_IP": "",
    "ZYPEHOST_SUBDOMAINS_NODE_PUBLIC_IPS": "",
}
missing = []
for key, value in defaults.items():
    if not re.search(rf'(?m)^\s*(?:export\s+)?{re.escape(key)}\s*=', s):
        missing.append(f'{key}={value}')
if missing:
    s = s.rstrip() + "\n\n# ZypeHost OAuth, Admin API and Minecraft-only Cloudflare subdomains\n" + "\n".join(missing) + "\n"
    p.write_text(s, encoding='utf-8')
    print(f"{len(missing)} fehlende ZypeHost-Variablen ergänzt.")
else:
    print("Alle ZypeHost-Variablen sind bereits vorhanden; nichts überschrieben.")
PYENV

# Run only the dedicated OAuth migration; do not execute unrelated pending migrations.
php artisan migrate --force --path=database/migrations/2026_10_31_000000_create_zypehost_oauth_accounts_table.php || fail "OAuth-Datenbankmigration fehlgeschlagen. Prüfe die Datenbankverbindung."
info "OAuth-Datenbanktabelle bereit."
php artisan migrate --force --path=database/migrations/2026_11_03_000000_create_zypehost_subdomains_table.php || fail "Subdomain-Datenbankmigration fehlgeschlagen."
info "Minecraft-Subdomain-Datenbanktabelle bereit."

# --- Step 4: clear cache + rebuild frontend automatically -----------------
info "Leere Cache und baue das Frontend neu (das kann ein paar Minuten dauern)..."
php artisan optimize:clear || true
export NODE_OPTIONS=--openssl-legacy-provider
if [[ "$BUILD_TOOL" == "yarn" ]]; then
    yarn build:production
else
    npm run build:production
fi

# A missing bundle makes the panel render only its wrapper background. Do not
# report a successful install unless the frontend bundle exists and is JS.
APP_BUNDLE="$(find "$PANEL_DIR/public/assets" -maxdepth 1 -type f -name 'bundle.*.js' -print -quit 2>/dev/null || true)"
[[ -n "$APP_BUNDLE" ]] || fail "Frontend-Build fehlgeschlagen: public/assets/bundle.*.js fehlt. Siehe Build-Ausgabe oben."
python3 - "$APP_BUNDLE" <<'PYBUNDLE' || fail "Frontend-Bundle enthält HTML statt JavaScript: $APP_BUNDLE"
from pathlib import Path
import sys
head = Path(sys.argv[1]).read_bytes()[:512].lstrip().lower()
if head.startswith((b'<!doctype html', b'<html')):
    raise SystemExit(1)
PYBUNDLE
info "Pterodactyl-Frontend-Bundle geprüft: ${APP_BUNDLE##*/}"

ROUTE_OUTPUT="$(php artisan route:list --path=zypehost --no-ansi 2>&1)" || fail "Laravel konnte die Routenliste nicht laden: $ROUTE_OUTPUT"
printf '%s\n' "$ROUTE_OUTPUT"
printf '%s\n' "$ROUTE_OUTPUT" | grep -q 'auth/zypehost/discord' || fail "Discord-OAuth-Route fehlt in Laravel route:list."
printf '%s\n' "$ROUTE_OUTPUT" | grep -q 'auth/zypehost/google' || fail "Google-OAuth-Route fehlt in Laravel route:list."
SUBDOMAIN_ROUTE_OUTPUT="$(php artisan route:list --path=zypehost-subdomains --no-ansi 2>&1)" || fail "Subdomain-Routen konnten nicht geladen werden: $SUBDOMAIN_ROUTE_OUTPUT"
printf '%s\n' "$SUBDOMAIN_ROUTE_OUTPUT"
printf '%s\n' "$SUBDOMAIN_ROUTE_OUTPUT" | grep -q 'zypehost-subdomains' || fail "Minecraft-Subdomain-API-Routen fehlen."
info "Fertig. ZypeHost v21 ist installiert — Theme, OAuth und Minecraft-Subdomains mit eigenem Navigationstab registriert."
info ""
info "Wichtig zum Favicon: Browser cachen Favicons besonders hartnäckig (unabhängig"
info "vom normalen Seiten-Cache). Falls im Tab weiter der alte Vogel zu sehen ist,"
info "obwohl die Datei hier auf dem Server jetzt richtig liegt:"
info "  - Tab komplett schliessen und neu öffnen (nicht nur neu laden)"
info "  - oder im Privat-/Inkognito-Fenster testen"
info "  - oder Browser-Cache für die Domain gezielt leeren"
info "OAuth-Callback-URLs: /auth/zypehost/discord/callback und /auth/zypehost/google/callback"
info "Minecraft-Subdomains: nur Minecraft-Eggs, nur blocknova.de, Cloudflare-DNS-only A/SRV Records."
info "Trage echte Discord-/Google-Clientdaten, ZypeHost-API-Key sowie CLOUDFLARE_API_TOKEN und CLOUDFLARE_ZONE_ID in $PANEL_DIR/.env ein."
info "Danach: cd $PANEL_DIR && php artisan config:clear && php artisan route:clear && php artisan config:cache"
info "Server-seitig geprueft werden kann das mit:"
info "  ls -la $FAVICON_DIR"
