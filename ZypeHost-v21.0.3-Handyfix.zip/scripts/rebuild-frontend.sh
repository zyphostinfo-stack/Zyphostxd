#!/usr/bin/env bash
set -Eeuo pipefail

PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
fail(){ echo "[ZypeHost Frontend] ERROR: $*" >&2; exit 1; }
info(){ echo "[ZypeHost Frontend] $*"; }

[[ -f "$PANEL_DIR/artisan" ]] || fail "Pterodactyl nicht gefunden: $PANEL_DIR"
[[ -f "$PANEL_DIR/package.json" ]] || fail "package.json nicht gefunden: $PANEL_DIR"
command -v php >/dev/null 2>&1 || fail "PHP CLI wurde nicht gefunden."
command -v node >/dev/null 2>&1 || fail "Node.js wurde nicht gefunden."
command -v python3 >/dev/null 2>&1 || fail "python3 wurde nicht gefunden."
node -e "const p=require('$PANEL_DIR/package.json'); if (!p.scripts || !p.scripts['build:production']) process.exit(1)" 2>/dev/null \
    || fail "package.json enthält kein build:production-Script."

if command -v yarn >/dev/null 2>&1; then
    BUILD_TOOL="yarn"
elif command -v npm >/dev/null 2>&1; then
    BUILD_TOOL="npm"
else
    fail "Weder Yarn noch npm gefunden."
fi

cd "$PANEL_DIR"
export NODE_OPTIONS=--openssl-legacy-provider
info "Baue das Pterodactyl-Frontend mit $BUILD_TOOL ..."
if [[ "$BUILD_TOOL" == "yarn" ]]; then
    yarn build:production
else
    npm run build:production
fi

info "Leere Laravel-Caches ..."
php artisan optimize:clear

APP_BUNDLE="$(find "$PANEL_DIR/public/assets" -maxdepth 1 -type f -name 'bundle.*.js' -print -quit 2>/dev/null || true)"
[[ -n "$APP_BUNDLE" ]] || fail "Build ohne Ergebnis: public/assets/bundle.*.js fehlt."
python3 - "$APP_BUNDLE" <<'PYBUNDLE' || fail "Bundle enthält HTML statt JavaScript: $APP_BUNDLE"
from pathlib import Path
import sys
head = Path(sys.argv[1]).read_bytes()[:512].lstrip().lower()
if head.startswith((b'<!doctype html', b'<html')):
    raise SystemExit(1)
PYBUNDLE
info "Bundle gefunden: ${APP_BUNDLE##*/}"
info "Wenn weiterhin nur der Hintergrund erscheint, prüfe im Browser-Netzwerk-Tab, dass /assets/${APP_BUNDLE##*/} mit JavaScript (nicht text/html) antwortet."
