/* ZypeHost mobile server menu + Minecraft-only Cloudflare subdomains. Loaded by wrapper.blade.php. */
(function () {
    'use strict';

    var DOMAIN = 'zyphost.de';
    var lastServer = '';
    var lastEligibility = null;
    var lastData = null;
    var requestBusy = false;
    var root = null;
    var mobileMenu = null;
    var mobileMenuList = null;
    var mobileNavContainer = null;
    var mobileNavServer = '';
    var mobileMenuServer = '';

    function serverContext() {
        var match = window.location.pathname.match(/\/server\/([^/]+)(?:\/|$)/i);
        if (!match) return null;
        return { id: decodeURIComponent(match[1]), onSubdomains: /\/subdomains?\/?$/i.test(window.location.pathname) };
    }

    function csrfToken() {
        var node = document.querySelector('meta[name="csrf-token"]');
        return node ? node.getAttribute('content') || '' : '';
    }

    function endpoint(serverId) {
        return '/api/client/servers/' + encodeURIComponent(serverId) + '/zypehost-subdomains';
    }

    function api(serverId, method, path, body) {
        var headers = { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' };
        var csrf = csrfToken();
        if (csrf) headers['X-CSRF-TOKEN'] = csrf;
        if (body !== undefined) headers['Content-Type'] = 'application/json';
        return fetch(endpoint(serverId) + (path || ''), {
            method: method || 'GET',
            credentials: 'same-origin',
            headers: headers,
            body: body === undefined ? undefined : JSON.stringify(body),
        }).then(function (response) {
            return response.text().then(function (raw) {
                var data = {};
                try { data = raw ? JSON.parse(raw) : {}; } catch (_) { data = { message: raw || 'Ungültige Serverantwort.' }; }
                if (!response.ok) {
                    var error = new Error(data.message || ('HTTP ' + response.status));
                    error.status = response.status;
                    error.data = data;
                    throw error;
                }
                return data;
            });
        });
    }

    function escapeHtml(value) {
        return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
        });
    }

    function serverNavLinks(serverId) {
        var safeId = String(serverId || '');
        return Array.prototype.slice.call(document.querySelectorAll('a[href]')).filter(function (anchor) {
            if (anchor.closest && anchor.closest('#zypehost-mobile-server-menu')) return false;
            try {
                var path = new URL(anchor.getAttribute('href') || '', window.location.href).pathname;
                var match = path.match(/^\/server\/([^/]+)\/(console|files|databases|schedules|users|backups|network|startup|settings|activity|subdomains?)(?:\/.*)?$/i);
                return !!match && decodeURIComponent(match[1]) === safeId;
            } catch (_) { return false; }
        });
    }

    function findServerNavContainer(links) {
        if (!links || !links.length) return null;
        var node = links[0].parentElement;
        while (node && node !== document.body) {
            var found = Array.prototype.slice.call(node.querySelectorAll('a[href]')).filter(function (anchor) {
                return links.indexOf(anchor) !== -1;
            });
            if (found.length >= Math.min(5, links.length)) return node;
            node = node.parentElement;
        }
        return links[0].parentElement;
    }

    function ensureResponsiveNavStyle() {
        if (document.getElementById('zypehost-responsive-server-nav-style')) return;
        var style = document.createElement('style');
        style.id = 'zypehost-responsive-server-nav-style';
        style.textContent =
            '@media(max-width:1024px){' +
                '[data-zypehost-responsive-nav="1"]{' +
                    'display:flex!important;flex-flow:row nowrap!important;align-items:center!important;' +
                    'justify-content:flex-start!important;gap:0!important;width:100%!important;' +
                    'max-width:100%!important;height:auto!important;max-height:none!important;' +
                    'overflow:visible!important;white-space:normal!important;box-sizing:border-box!important;' +
                    'margin:0!important;padding:0!important;list-style:none!important' +
                '}' +
                '[data-zypehost-responsive-nav="1"]>:not([data-zypehost-mobile-nav-toggle="1"]){' +
                    'display:none!important' +
                '}' +
                '[data-zypehost-responsive-nav="1"]>[data-zypehost-mobile-nav-toggle="1"]{' +
                    'display:flex!important;flex:0 0 auto!important;width:auto!important;' +
                    'min-width:96px!important;max-width:none!important;overflow:visible!important;' +
                    'align-items:center!important;justify-content:center!important;list-style:none!important' +
                '}' +
                '[data-zypehost-mobile-nav-toggle="1"] .zypehost-mobile-nav-button{' +
                    'display:flex!important;align-items:center!important;justify-content:center!important;gap:10px!important;' +
                    'min-width:96px!important;width:auto!important;height:48px!important;padding:0 14px!important;' +
                    'border:1px solid #45617f!important;border-radius:12px!important;' +
                    'background:linear-gradient(135deg,#24466a,#17283e)!important;color:#fff!important;' +
                    'font-size:14px!important;font-weight:750!important;line-height:1!important;cursor:pointer!important;' +
                    'box-shadow:0 5px 15px rgba(0,0,0,.26)!important' +
                '}' +
                '[data-zypehost-mobile-nav-toggle="1"] .zypehost-mobile-nav-icon{' +
                    'display:flex!important;flex:0 0 21px!important;flex-direction:column!important;' +
                    'justify-content:center!important;gap:4px!important;width:21px!important;height:20px!important' +
                '}' +
                '[data-zypehost-mobile-nav-toggle="1"] .zypehost-mobile-nav-icon i{' +
                    'display:block!important;width:21px!important;height:2px!important;border-radius:2px!important;' +
                    'background:#e8f3ff!important' +
                '}' +
                '[data-zypehost-mobile-nav-toggle="1"] .zypehost-mobile-nav-label{' +
                    'display:inline!important;font-size:14px!important;font-weight:750!important;letter-spacing:.01em!important' +
                '}' +
                '#zypehost-mobile-server-menu{display:block;position:fixed;z-index:10001;' +
                    'max-width:calc(100vw - 24px);overflow:auto;background:rgba(18,29,45,.98);' +
                    'border:1px solid #4a607b;border-radius:16px;color:#f8fafc;' +
                    'box-shadow:0 20px 52px rgba(0,0,0,.48);padding:12px;' +
                    'font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;' +
                    'box-sizing:border-box;-webkit-overflow-scrolling:touch}' +
                '#zypehost-mobile-server-menu [data-zypehost-menu-heading]{' +
                    'display:flex;align-items:center;justify-content:space-between;gap:12px;' +
                    'padding:10px 10px 13px;color:#b5c6dd;font-size:13px;font-weight:800;' +
                    'letter-spacing:.12em;text-transform:uppercase;border-bottom:1px solid #334155}' +
                '#zypehost-mobile-server-menu [data-zypehost-menu-close]{' +
                    'width:40px;height:40px;border:0;border-radius:10px;background:#26364c;' +
                    'color:#fff;font-size:22px;line-height:1;cursor:pointer}' +
                '#zypehost-mobile-server-menu [data-zypehost-menu-items]{' +
                    'display:flex;flex-direction:column;gap:6px;padding-top:10px}' +
                '#zypehost-mobile-server-menu .zypehost-mobile-server-link{' +
                    'display:flex!important;align-items:center!important;gap:12px!important;' +
                    'width:100%!important;min-width:0!important;max-width:none!important;' +
                    'min-height:50px!important;padding:14px 16px!important;border:0!important;border-radius:10px!important;' +
                    'background:transparent!important;color:#e7edf6!important;text-decoration:none!important;' +
                    'font-size:15px!important;font-weight:650!important;white-space:normal!important;' +
                    'box-sizing:border-box!important;cursor:pointer!important}' +
                '#zypehost-mobile-server-menu .zypehost-mobile-server-link:hover,' +
                '#zypehost-mobile-server-menu .zypehost-mobile-server-link[aria-current="page"]{' +
                    'background:#29394f!important;color:#fff!important}' +
            '}' +
            '@media(min-width:1025px){#zypehost-mobile-server-menu{display:none!important}' +
                '[data-zypehost-mobile-nav-toggle="1"]{display:none!important}' +
            '}';
        document.head.appendChild(style);
    }

    function ensureMobileMenu() {
        if (mobileMenu && document.body.contains(mobileMenu)) return mobileMenu;
        mobileMenu = document.getElementById('zypehost-mobile-server-menu');
        if (mobileMenu) {
            mobileMenuList = mobileMenu.querySelector('[data-zypehost-menu-items]');
            return mobileMenu;
        }

        mobileMenu = document.createElement('div');
        mobileMenu.id = 'zypehost-mobile-server-menu';
        mobileMenu.setAttribute('role', 'dialog');
        mobileMenu.setAttribute('aria-label', 'Servernavigation');
        mobileMenu.style.display = 'none';
        mobileMenu.innerHTML =
            '<div data-zypehost-menu-heading><span>Servermenü</span>' +
                '<button type="button" data-zypehost-menu-close aria-label="Menü schließen">×</button>' +
            '</div><div data-zypehost-menu-items></div>';
        mobileMenuList = mobileMenu.querySelector('[data-zypehost-menu-items]');
        mobileMenu.querySelector('[data-zypehost-menu-close]').addEventListener('click', closeMobileMenu);
        document.body.appendChild(mobileMenu);

        document.addEventListener('click', function (event) {
            if (!mobileMenu || mobileMenu.style.display === 'none') return;
            var target = event.target;
            if (mobileMenu.contains(target)) return;
            if (target && target.closest && target.closest('[data-zypehost-mobile-nav-toggle="1"]')) return;
            closeMobileMenu();
        });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') closeMobileMenu();
        });
        window.addEventListener('resize', function () {
            if (mobileMenu && mobileMenu.style.display !== 'none') {
                if (window.innerWidth > 1024) closeMobileMenu();
                else positionMobileMenu();
            }
        });
        window.addEventListener('scroll', function () {
            if (mobileMenu && mobileMenu.style.display !== 'none') positionMobileMenu();
        }, true);
        return mobileMenu;
    }

    function closeMobileMenu() {
        if (mobileMenu) mobileMenu.style.display = 'none';
        Array.prototype.slice.call(document.querySelectorAll('[data-zypehost-mobile-nav-button="1"]'))
            .forEach(function (button) {
                button.setAttribute('aria-expanded', 'false');
                button.setAttribute('aria-label', 'Servermenü öffnen');
            });
    }

    function positionMobileMenu() {
        if (!mobileMenu || !mobileNavContainer || window.innerWidth > 1024) return;
        var rect = mobileNavContainer.getBoundingClientRect();
        var width = Math.min(420, Math.max(260, window.innerWidth - 24));
        width = Math.min(width, window.innerWidth - 24);
        var left = Math.max(12, Math.min(rect.left, window.innerWidth - width - 12));
        var top = Math.max(12, Math.min(rect.bottom + 6, window.innerHeight - 150));
        mobileMenu.style.left = left + 'px';
        mobileMenu.style.top = top + 'px';
        mobileMenu.style.width = width + 'px';
        mobileMenu.style.maxHeight = Math.max(120, window.innerHeight - top - 16) + 'px';
    }

    function populateMobileMenu(serverId) {
        ensureMobileMenu();
        if (!mobileMenuList) return;
        mobileMenuList.innerHTML = '';
        serverNavLinks(serverId).forEach(function (anchor) {
            var item = anchor.closest('li') || anchor.parentElement;
            if (anchor.style.display === 'none' || (item && item.style.display === 'none')) return;

            var link = anchor.cloneNode(true);
            link.className = 'zypehost-mobile-server-link';
            link.removeAttribute('style');
            link.setAttribute('role', 'menuitem');
            link.setAttribute('aria-label', (anchor.textContent || '').trim());
            link.addEventListener('click', function (event) {
                event.preventDefault();
                closeMobileMenu();
                anchor.click();
            });
            mobileMenuList.appendChild(link);
        });
    }

    function openMobileMenu(serverId, button) {
        if (!mobileMenu || mobileNavServer !== serverId || !mobileNavContainer) return;
        populateMobileMenu(serverId);
        positionMobileMenu();
        mobileMenu.style.display = 'block';
        mobileMenuServer = serverId;
        button.setAttribute('aria-expanded', 'true');
        button.setAttribute('aria-label', 'Servermenü schließen');
    }

    function ensureMobileNav(serverId) {
        var links = serverNavLinks(serverId);
        if (!links.length) return;
        var container = findServerNavContainer(links);
        if (!container) return;

        Array.prototype.slice.call(document.querySelectorAll('[data-zypehost-mobile-nav-toggle="1"]'))
            .forEach(function (toggle) {
                if (!container.contains(toggle)) toggle.remove();
            });
        Array.prototype.slice.call(document.querySelectorAll('[data-zypehost-responsive-nav="1"]'))
            .forEach(function (nav) {
                if (nav !== container) nav.removeAttribute('data-zypehost-responsive-nav');
            });
        container.setAttribute('data-zypehost-responsive-nav', '1');
        ensureResponsiveNavStyle();
        ensureMobileMenu();

        var toggle = container.querySelector('[data-zypehost-mobile-nav-toggle="1"]');
        if (!toggle || toggle.parentElement !== container) {
            if (toggle) toggle.remove();
            var reference = links[0];
            var referenceItem = reference.closest('li');
            var isList = /^(UL|OL)$/.test(container.tagName || '');
            var button = document.createElement('button');
            button.type = 'button';
            button.className = 'zypehost-mobile-nav-button';
            button.setAttribute('data-zypehost-mobile-nav-button', '1');
            button.setAttribute('aria-label', 'Servermenü öffnen');
            button.setAttribute('aria-expanded', 'false');
            button.setAttribute('aria-controls', 'zypehost-mobile-server-menu');
            button.innerHTML = '<span class="zypehost-mobile-nav-icon" aria-hidden="true"><i></i><i></i><i></i></span><span class="zypehost-mobile-nav-label">Menü</span>';

            if (isList) {
                toggle = document.createElement('li');
                toggle.className = referenceItem ? referenceItem.className : '';
                toggle.setAttribute('data-zypehost-mobile-nav-toggle', '1');
                toggle.style.listStyle = 'none';
                toggle.appendChild(button);
            } else {
                toggle = button;
                toggle.setAttribute('data-zypehost-mobile-nav-toggle', '1');
            }

            button.addEventListener('click', function (event) {
                event.preventDefault();
                event.stopPropagation();
                if (mobileMenu && mobileMenu.style.display !== 'none' && mobileMenuServer === mobileNavServer) {
                    closeMobileMenu();
                } else {
                    openMobileMenu(mobileNavServer, button);
                }
            });
            container.insertBefore(toggle, container.firstChild);
        }

        mobileNavContainer = container;
        mobileNavServer = serverId;
        populateMobileMenu(serverId);
        if (mobileMenu && mobileMenu.style.display !== 'none') {
            mobileMenuServer = serverId;
            positionMobileMenu();
        }
    }

    function removeMobileNav() {
        closeMobileMenu();
        Array.prototype.slice.call(document.querySelectorAll('[data-zypehost-mobile-nav-toggle="1"]'))
            .forEach(function (toggle) { toggle.remove(); });
        Array.prototype.slice.call(document.querySelectorAll('[data-zypehost-responsive-nav="1"]'))
            .forEach(function (container) { container.removeAttribute('data-zypehost-responsive-nav'); });
        mobileNavContainer = null;
        mobileNavServer = '';
        mobileMenuServer = '';
    }

    function styleSubdomainTab(tab, active) {
        if (!tab) return;
        tab.style.display = '';
        tab.style.whiteSpace = 'nowrap';
        tab.style.cursor = 'pointer';
        tab.style.textDecoration = 'none';
        tab.style.borderBottom = active ? '2px solid #95c900' : '2px solid transparent';
        tab.style.color = active ? '#d7f2a0' : '';
        tab.setAttribute('aria-current', active ? 'page' : 'false');
    }

    function ensureSubdomainTab(serverId, visible, active) {
        var tab = document.querySelector('[data-zypehost-subdomain-tab="1"]');
        if (!visible || !serverId) {
            if (tab) tab.style.display = 'none';
            return;
        }

        var links = serverNavLinks(serverId);
        if (!links.length) {
            if (tab) tab.style.display = 'none';
            return;
        }

        var path = '/server/' + encodeURIComponent(serverId) + '/subdomains';
        var container = findServerNavContainer(links);
        if (!container) return;
        container.setAttribute('data-zypehost-responsive-nav', '1');
        ensureResponsiveNavStyle();

        // Reuse the native navigation element's CSS classes so the new item
        // looks like Console / Files / Network, but do not copy its active state.
        var reference = links.filter(function (a) {
            return !a.getAttribute('aria-current') && !/border-b-|text-primary|text-green/i.test(a.className || '');
        })[0] || links[0];

        if (!tab || !document.body.contains(tab) || tab.getAttribute('data-server-id') !== serverId) {
            if (tab) tab.remove();
            tab = document.createElement('a');
            tab.setAttribute('data-zypehost-subdomain-tab', '1');
            tab.setAttribute('data-server-id', serverId);
            tab.setAttribute('href', path);
            tab.className = reference.className || '';
            if (reference.getAttribute('style')) tab.setAttribute('style', reference.getAttribute('style'));
            var referenceSpan = reference.querySelector('span');
            if (referenceSpan) {
                var label = document.createElement('span');
                label.className = referenceSpan.className || '';
                label.textContent = 'Subdomain';
                tab.appendChild(label);
            } else {
                tab.textContent = 'Subdomain';
            }
            tab.addEventListener('click', function (event) {
                // This is a script-rendered page, not a React route. Keep the
                // current SPA view mounted and let our overlay handle the URL.
                event.preventDefault();
                event.stopPropagation();
                var nextPath = '/server/' + encodeURIComponent(serverId) + '/subdomains';
                if (window.location.pathname !== nextPath) {
                    window.history.pushState({ zypehostSubdomains: true }, '', nextPath);
                }
                scheduleSync();
            });

            var network = links.filter(function (a) { return /\/network(?:\/|$)/i.test(a.getAttribute('href') || ''); })[0];
            var insertAfter = network || links[links.length - 1];
            var isList = /^(UL|OL)$/.test(container.tagName || '');
            var wrapper = null;
            var linkParent = insertAfter.parentElement;
            if (isList) {
                wrapper = document.createElement('li');
                wrapper.className = (linkParent && linkParent.tagName === 'LI') ? linkParent.className : '';
                wrapper.appendChild(tab);
                // Insert beside the existing list item, not inside it. Nesting
                // an <li> within another <li> makes the tab disappear or
                // renders it incorrectly in browsers and mobile WebViews.
                if (linkParent && linkParent.parentElement === container) {
                    linkParent.insertAdjacentElement('afterend', wrapper);
                } else {
                    insertAfter.insertAdjacentElement('afterend', wrapper);
                }
            } else if (linkParent && linkParent !== container && linkParent.parentElement === container) {
                // Several panel builds wrap each nav link in its own flex item.
                // Clone the wrapper and add it as a sibling, rather than
                // inserting a wrapper inside the link's existing flex item.
                wrapper = linkParent.cloneNode(false);
                wrapper.appendChild(tab);
                linkParent.insertAdjacentElement('afterend', wrapper);
            } else {
                insertAfter.insertAdjacentElement('afterend', tab);
            }
        } else {
            tab.setAttribute('href', path);
        }

        styleSubdomainTab(tab, !!active);
    }

    function setSubdomainTabVisible(visible, serverId, active) {
        if (serverId) {
            ensureSubdomainTab(serverId, visible, active);
        } else {
            var tab = document.querySelector('[data-zypehost-subdomain-tab="1"]');
            if (tab) tab.style.display = 'none';
        }
        // Hide any legacy tab provided by a different plugin for non-Minecraft
        // servers, but do not depend on one existing in the first place.
        Array.prototype.slice.call(document.querySelectorAll('a[href]')).filter(function (anchor) {
            if (anchor.hasAttribute('data-zypehost-subdomain-tab')) return false;
            var href = anchor.getAttribute('href') || '';
            var label = (anchor.textContent || '').trim().toLowerCase();
            return /\/subdomains?(?:\/|$)/i.test(href) || label === 'subdomain' || label === 'subdomains';
        }).forEach(function (anchor) {
            var item = anchor.closest('li') || anchor.parentElement || anchor;
            item.style.display = visible ? '' : 'none';
        });
    }

    function ensureRoot() {
        if (root && document.body.contains(root)) return root;
        root = document.getElementById('zypehost-subdomain-ui');
        if (root) return root;
        root = document.createElement('div');
        root.id = 'zypehost-subdomain-ui';
        root.style.cssText = 'display:none;position:fixed;z-index:9998;top:54px;left:0;right:0;bottom:0;overflow:auto;background:#0e111b;color:#e9eef8;font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif;padding:26px 22px 40px;box-sizing:border-box;';
        document.body.appendChild(root);
        return root;
    }

    function showMessage(message, kind) {
        var node = root && root.querySelector('[data-zypehost-message]');
        if (!node) return;
        node.textContent = message;
        node.style.display = message ? 'block' : 'none';
        node.style.color = kind === 'error' ? '#fecaca' : '#bbf7d0';
        node.style.background = kind === 'error' ? 'rgba(127,29,29,.24)' : 'rgba(20,83,45,.24)';
    }

    function renderLoading() {
        var r = ensureRoot();
        r.innerHTML = '<div style="max-width:980px;margin:10px auto"><div style="color:#93a4bd">ZypeHost · Minecraft Subdomains</div><h1 style="font-size:26px;margin:10px 0 8px;color:#fff">Subdomains</h1><p style="color:#94a3b8">Cloudflare-DNS wird geladen …</p></div>';
    }

    function renderNotMinecraft() {
        var r = ensureRoot();
        r.innerHTML = '<div style="max-width:900px;margin:32px auto;padding:26px;border:1px solid #293244;border-radius:14px;background:#151a27"><h2 style="margin:0 0 8px;color:#fff">Subdomains nur für Minecraft</h2><p style="color:#a8b5c9;margin:0">Diese Funktion ist ausschließlich für Minecraft-Server freigeschaltet.</p></div>';
    }

    function render(data, serverId) {
        lastServer = serverId;
        lastEligibility = true;
        lastData = data;
        var r = ensureRoot();
        var allocations = Array.isArray(data.allocations) ? data.allocations : [];
        var rows = Array.isArray(data.subdomains) ? data.subdomains : [];
        var allocationOptions = allocations.map(function (item) {
            return '<option value="' + escapeHtml(item.id) + '">' + escapeHtml(item.label) + '</option>';
        }).join('');
        var subdomainRows = rows.length ? rows.map(function (item) {
            return '<div class="zy-row"><div style="min-width:0"><div style="font-weight:700;color:#fff;overflow-wrap:anywhere">' + escapeHtml(item.fqdn) + '</div><small style="color:#93a4bd">Minecraft Java: nur diese Adresse eingeben · Port automatisch</small></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="zy-copy" data-copy="' + escapeHtml(item.fqdn) + '">Adresse kopieren</button><button type="button" class="zy-delete" data-delete="' + escapeHtml(item.id) + '" aria-label="Subdomain schließen">Schließen</button></div></div>';
        }).join('') : '<p style="color:#93a4bd;margin:12px 0">Du hast noch keine Subdomain für diesen Minecraft-Server.</p>';

        r.innerHTML = '' +
            '<div class="zy-wrap">' +
                '<div style="display:flex;align-items:flex-end;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:20px">' +
                    '<div><div style="color:#8da3c4;font-size:12px;letter-spacing:.12em;text-transform:uppercase">ZypeHost · Minecraft</div><h1 style="font-size:27px;line-height:1.2;margin:8px 0 5px;color:#fff">Subdomains</h1><p style="color:#9cabc2;margin:0">Erstelle eine eigene Minecraft-Adresse für deinen Server.</p></div>' +
                    '<div style="padding:9px 13px;border:1px solid #334155;border-radius:9px;color:#b6c5dc;background:#151c29">Nur <strong style="color:#fff">' + DOMAIN + '</strong></div>' +
                '</div>' +
                '<div data-zypehost-message style="display:none;margin-bottom:16px;padding:12px 14px;border-radius:9px"></div>' +
                '<section class="zy-card"><h2>Subdomain erstellen</h2>' +
                    '<form id="zy-create-form">' +
                        '<label>SUBDOMAIN<input id="zy-subdomain" name="subdomain" type="text" maxlength="48" minlength="2" pattern="[a-z0-9][a-z0-9-]*[a-z0-9]" placeholder="survival" required autocomplete="off" /></label>' +
                        '<label>DOMAIN<select disabled><option>' + DOMAIN + '</option></select></label>' +
                        '<label>ALLOCATION<select id="zy-allocation" required>' + (allocationOptions || '<option value="">Keine öffentliche Allocation verfügbar</option>') + '</select></label>' +
                        '<button class="zy-create" type="submit" ' + (allocations.length ? '' : 'disabled') + '>Subdomain erstellen</button>' +
                    '</form>' +
                     '<small style="display:block;color:#91a0b6;margin-top:12px">Minecraft Java: Zum Beitreten nur die Subdomain eingeben – auch bei einem abweichenden Port. Der Port wird über SRV-DNS gesetzt. Cloudflare-Proxy bleibt deaktiviert.</small>' +
                '</section>' +
                '<section class="zy-card" style="margin-top:18px"><h2>Deine Subdomains</h2><div id="zy-list">' + subdomainRows + '</div></section>' +
                '<div style="color:#718198;font-size:12px;margin-top:18px">Domain fest vorgegeben: ' + DOMAIN + ' · Nur Minecraft-Eggs sind serverseitig zugelassen.</div>' +
            '</div>';

        var style = document.createElement('style');
        style.id = 'zypehost-subdomains-style';
        style.textContent = '#zypehost-subdomain-ui .zy-wrap{max-width:980px;margin:0 auto}#zypehost-subdomain-ui .zy-card{background:#151b28;border:1px solid #2b3547;border-radius:13px;padding:20px 22px;box-shadow:0 12px 30px rgba(0,0,0,.18)}#zypehost-subdomain-ui .zy-card h2{font-size:18px;color:#f8fafc;margin:0 0 17px}#zypehost-subdomain-ui form{display:grid;grid-template-columns:1fr 1fr;gap:15px}#zypehost-subdomain-ui label{display:flex;flex-direction:column;gap:8px;color:#aab8cc;font-size:11px;font-weight:700;letter-spacing:.06em}#zypehost-subdomain-ui input,#zypehost-subdomain-ui select{height:43px;box-sizing:border-box;width:100%;border:1px solid #49586d;border-radius:8px;background:#465365;color:#fff;padding:0 12px;font-size:14px;outline:none}#zypehost-subdomain-ui select:disabled{opacity:.9}#zypehost-subdomain-ui input:focus,#zypehost-subdomain-ui select:focus{border-color:#9ac600;box-shadow:0 0 0 2px rgba(154,198,0,.16)}#zypehost-subdomain-ui .zy-create{grid-column:1/-1;justify-self:start;border:0;border-radius:9px;background:#95c900;color:#10170a;font-weight:800;padding:12px 18px;cursor:pointer}#zypehost-subdomain-ui .zy-create:disabled{opacity:.5;cursor:not-allowed}#zypehost-subdomain-ui .zy-row{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:14px 0;border-bottom:1px solid #293548}#zypehost-subdomain-ui .zy-row:last-child{border-bottom:0}#zypehost-subdomain-ui .zy-copy,#zypehost-subdomain-ui .zy-delete{border:1px solid #42516a;background:#222d3e;color:#e9eef8;border-radius:8px;padding:8px 12px;cursor:pointer}#zypehost-subdomain-ui .zy-delete{border-color:#7f333b;color:#fecaca}@media(max-width:650px){#zypehost-subdomain-ui{top:50px;padding:18px 12px}#zypehost-subdomain-ui form{grid-template-columns:1fr}#zypehost-subdomain-ui .zy-row{align-items:flex-start;flex-direction:column}}';
        var oldStyle = document.getElementById('zypehost-subdomains-style');
        if (oldStyle) oldStyle.remove();
        document.head.appendChild(style);

        var form = r.querySelector('#zy-create-form');
        if (form) form.addEventListener('submit', function (event) {
            event.preventDefault();
            if (requestBusy) return;
            requestBusy = true;
            var button = form.querySelector('button[type="submit"]');
            button.disabled = true;
            button.textContent = 'Wird erstellt …';
            showMessage('', 'success');
            api(serverId, 'POST', '', {
                subdomain: r.querySelector('#zy-subdomain').value.trim().toLowerCase(),
                allocation_id: Number(r.querySelector('#zy-allocation').value),
            }).then(function () {
                showMessage('Subdomain wurde in Cloudflare erstellt.', 'success');
                return api(serverId, 'GET', '');
            }).then(function (latest) {
                render(latest, serverId);
            }).catch(function (error) {
                showMessage(error.message || 'Die Subdomain konnte nicht erstellt werden.', 'error');
                button.disabled = false;
                button.textContent = 'Subdomain erstellen';
            }).finally(function () { requestBusy = false; });
        });

        r.querySelectorAll('[data-delete]').forEach(function (button) {
            button.addEventListener('click', function () {
                var id = button.getAttribute('data-delete');
                if (!window.confirm('Subdomain schließen und die zugehörigen DNS-Einträge entfernen?')) return;
                button.disabled = true;
                api(serverId, 'DELETE', '/' + encodeURIComponent(id)).then(function () {
                    return api(serverId, 'GET', '');
                }).then(function (latest) {
                    render(latest, serverId);
                    showMessage('Subdomain wurde geschlossen und gelöscht.', 'success');
                }).catch(function (error) {
                    button.disabled = false;
                    showMessage(error.message || 'Löschen fehlgeschlagen.', 'error');
                });
            });
        });

        r.querySelectorAll('[data-copy]').forEach(function (button) {
            button.addEventListener('click', function () {
                var text = button.getAttribute('data-copy');
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(text).then(function () { showMessage('Adresse kopiert: ' + text, 'success'); });
                } else {
                    showMessage('Adresse: ' + text, 'success');
                }
            });
        });
    }

    function loadServer(serverId) {
        if (lastServer === serverId && lastEligibility !== null) return Promise.resolve({ eligible: lastEligibility, data: lastData });
        return api(serverId, 'GET', '').then(function (data) {
            lastServer = serverId;
            lastEligibility = true;
            lastData = data;
            return { eligible: true, data: data };
        }).catch(function (error) {
            if (error.data && error.data.code === 'minecraft_only') {
                lastServer = serverId;
                lastEligibility = false;
                lastData = null;
                return { eligible: false };
            }
            return { eligible: null, error: error };
        });
    }

    function sync() {
        var context = serverContext();
        var r = ensureRoot();
        if (!context) {
            r.style.display = 'none';
            setSubdomainTabVisible(false);
            removeMobileNav();
            lastServer = '';
            lastEligibility = null;
            lastData = null;
            return;
        }

        ensureMobileNav(context.id);
        loadServer(context.id).then(function (result) {
            if (result.eligible === false) {
                setSubdomainTabVisible(false, context.id, false);
                ensureMobileNav(context.id);
                if (context.onSubdomains) {
                    r.style.display = 'block';
                    renderNotMinecraft();
                } else {
                    r.style.display = 'none';
                }
                return;
            }

            if (result.eligible === true) {
                setSubdomainTabVisible(true, context.id, context.onSubdomains);
                ensureMobileNav(context.id);
                if (context.onSubdomains) {
                    r.style.display = 'block';
                    render(result.data, context.id);
                } else {
                    r.style.display = 'none';
                }
                return;
            }

            // Keep the existing extension visible if the API cannot be reached;
            // do not incorrectly hide the navigation because of a transient error.
            setSubdomainTabVisible(true, context.id, context.onSubdomains);
            ensureMobileNav(context.id);
            if (context.onSubdomains) {
                r.style.display = 'block';
                renderLoading();
                var wrap = r.querySelector('p');
                if (wrap) wrap.textContent = result.error && result.error.message ? result.error.message : 'Subdomain-Funktion konnte nicht geladen werden.';
            } else {
                r.style.display = 'none';
            }
        });
    }

    var queued = false;
    function scheduleSync() {
        if (queued) return;
        queued = true;
        window.setTimeout(function () { queued = false; sync(); }, 180);
    }

    ['pushState', 'replaceState'].forEach(function (method) {
        var original = history[method];
        history[method] = function () {
            var result = original.apply(this, arguments);
            scheduleSync();
            return result;
        };
    });
    window.addEventListener('popstate', scheduleSync);
    document.addEventListener('DOMContentLoaded', scheduleSync);
    document.addEventListener('DOMContentLoaded', function () {
        var app = document.getElementById('app');
        if (app) new MutationObserver(scheduleSync).observe(app, { childList: true, subtree: true });
        scheduleSync();
    });
    scheduleSync();
})();
