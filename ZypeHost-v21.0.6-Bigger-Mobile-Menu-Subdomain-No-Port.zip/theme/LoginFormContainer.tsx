import React, { forwardRef, useEffect, useState } from 'react';
import { Form } from 'formik';
import styled, { keyframes } from 'styled-components/macro';
import FlashMessageRender from '@/components/FlashMessageRender';

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
    title?: string;
};

/* ---- animation: the background + its glow orbs move together as one
   coupled scene instead of separate static layers ---- */
const drift = keyframes`
    0%   { background-position: 50% 50%, 0% 0%; }
    50%  { background-position: 54% 46%, 100% 100%; }
    100% { background-position: 50% 50%, 0% 0%; }
`;

const orbFloatA = keyframes`
    0%   { transform: translate(0, 0) scale(1); }
    50%  { transform: translate(26px, -18px) scale(1.08); }
    100% { transform: translate(0, 0) scale(1); }
`;

const orbFloatB = keyframes`
    0%   { transform: translate(0, 0) scale(1); }
    50%  { transform: translate(-22px, 20px) scale(1.06); }
    100% { transform: translate(0, 0) scale(1); }
`;

const orbFloatC = keyframes`
    0%   { transform: translate(0, 0) scale(1); }
    50%  { transform: translate(16px, 16px) scale(1.1); }
    100% { transform: translate(0, 0) scale(1); }
`;

const Page = styled.main`
    position: fixed;
    inset: 0;
    z-index: 1000;
    width: 100vw;
    min-height: 100dvh;
    overflow-y: auto;
    overflow-x: hidden;
    overscroll-behavior-y: contain;
    -webkit-overflow-scrolling: touch;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: max(36px, env(safe-area-inset-top)) 22px max(22px, env(safe-area-inset-bottom));
    > * {
        flex-shrink: 0;
    }
    background:
        linear-gradient(155deg, rgba(3, 12, 21, 0.48) 0%, rgba(3, 12, 21, 0.22) 45%, rgba(2, 8, 15, 0.78) 100%),
        url('/themes/zypehost/login-server-rack.jpg?v=21.0.6') center 48% / cover no-repeat;
    background-size: 140% 140%, cover;
    animation: ${drift} 26s ease-in-out infinite;
    isolation: isolate;

    @media (max-width: 760px) {
        justify-content: flex-start;
        padding: max(24px, env(safe-area-inset-top)) 14px calc(22px + env(safe-area-inset-bottom));
        background-position: center center, center 48%;
        background-size: 100% 100%, cover;
    }

    @media (max-width: 480px) {
        padding-left: 14px;
        padding-right: 14px;
    }

    @media (prefers-reduced-motion: reduce) {
        animation: none;
        &::before,
        &::after {
            animation: none;
        }
    }

    &::before,
    &::after {
        content: '';
        position: fixed;
        z-index: -1;
        pointer-events: none;
        border-radius: 50%;
        filter: blur(4px);
    }

    &::before {
        top: 12%;
        left: 8%;
        width: 340px;
        height: 340px;
        background: radial-gradient(circle, rgba(0, 213, 255, 0.16), transparent 70%);
        animation: ${orbFloatA} 12s ease-in-out infinite;
    }

    &::after {
        bottom: 10%;
        right: 10%;
        width: 300px;
        height: 300px;
        background: radial-gradient(circle, rgba(90, 238, 141, 0.12), transparent 70%);
        animation: ${orbFloatB} 14s ease-in-out infinite;
    }
`;

const AmbientOrb = styled.div`
    position: fixed;
    z-index: -1;
    top: 55%;
    left: 82%;
    width: 220px;
    height: 220px;
    border-radius: 50%;
    pointer-events: none;
    background: radial-gradient(circle, rgba(0, 150, 255, 0.10), transparent 70%);
    animation: ${orbFloatC} 16s ease-in-out infinite;

    @media (prefers-reduced-motion: reduce) {
        animation: none;
    }
`;

const TitleBlock = styled.div`
    width: min(980px, 100%);
    margin-bottom: 18px;
    flex: 0 0 auto;
    text-align: center;
    color: #fff;

    @media (max-width: 760px) {
        width: min(480px, 100%);
        margin-bottom: 14px;
    }
`;

const BrandMark = styled.div`
    display: inline-flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 14px;
    padding: 6px 14px 6px 6px;
    border: 1px solid rgba(255,255,255,.18);
    border-radius: 999px;
    background: rgba(0, 0, 0, .20);
    box-shadow: 0 10px 30px rgba(0,0,0,.16);
    backdrop-filter: blur(14px);
    color: rgba(255,255,255,.9);
    font-size: 11px;
    font-weight: 800;
    letter-spacing: .2em;
    text-transform: uppercase;
`;

/* replaces the old plain status-dot AND the plain "Z" letterform: now
   uses the real ZypeHost swoosh icon cropped from the brand logo, so the
   brand strip matches the actual logo instead of a generic mark */
const BrandBadge = styled.span`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 24px;
    height: 24px;
    border-radius: 7px;
    background: #fff;
    box-shadow: 0 0 0 1px rgba(255,255,255,.14) inset, 0 4px 10px rgba(11,94,198,.35);
    position: relative;
    overflow: hidden;

    img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        display: block;
    }

    &::after {
        content: '';
        position: absolute;
        top: -2px;
        right: -2px;
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #00d9ff;
        box-shadow: 0 0 8px rgba(0,217,255,.9);
    }
`;

const Title = styled.h1`
    margin: 0;
    color: #fff;
    font-size: clamp(28px, 4vw, 38px);
    line-height: 1.08;
    font-weight: 800;
    letter-spacing: -.035em;
    text-shadow: 0 8px 28px rgba(0,0,0,.36);
`;

const Subtitle = styled.p`
    margin: 10px auto 0;
    max-width: 620px;
    color: rgba(255,255,255,.70);
    font-size: 13px;
    line-height: 1.6;
`;

const Card = styled.section`
    position: relative;
    width: min(960px, 100%);
    flex: 0 0 auto;
    display: grid;
    /* v8: form pane first (left), logo pane second (right) — swapped from v7 */
    grid-template-columns: minmax(0, 1fr) minmax(280px, 39%);
    overflow: hidden;
    border: 1px solid rgba(255,255,255,.54);
    border-radius: 20px;
    background: linear-gradient(145deg, rgba(255,255,255,.99), rgba(245,249,253,.96));
    box-shadow:
        0 34px 100px rgba(0,0,0,.52),
        0 10px 30px rgba(0,0,0,.18);
    backdrop-filter: blur(18px);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, #21d4d0, #1674e6 42%, #6556e8 72%, #7bd957);
    }

    @media (max-width: 760px) {
        grid-template-columns: 1fr;
        width: min(480px, 100%);
        border-radius: 18px;
    }
`;

const LogoPane = styled.div`
    position: relative;
    min-height: 430px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 34px;
    box-sizing: border-box;
    background:
        radial-gradient(circle at 50% 45%, rgba(255,255,255,1), rgba(248,250,253,1) 64%, rgba(239,244,249,1));
    border-left: 1px solid #e2e8ef;

    &::before {
        content: '';
        position: absolute;
        inset: 28px;
        border: 2px solid rgba(25, 180, 200, .56);
        border-radius: 12px;
        box-shadow:
            inset 0 0 0 1px rgba(25,180,200,.08),
            0 0 30px rgba(25,180,200,.10);
        pointer-events: none;
    }

    img {
        position: relative;
        z-index: 1;
        display: block;
        width: min(320px, 88%);
        max-height: 220px;
        object-fit: contain;
        filter: drop-shadow(0 14px 22px rgba(35, 50, 65, .16));
        transition: transform .3s ease;
    }

    &:hover img {
        transform: translateY(-3px) scale(1.015);
    }

    @media (max-width: 760px) {
        display: none;
    }
`;

const FormPane = styled.div`
    min-width: 0;
    padding: 42px 44px 36px;
    box-sizing: border-box;

    @media (max-width: 760px) {
        padding: 28px 22px 24px;
    }

    @media (max-width: 420px) {
        padding: 22px 16px 20px;
    }
`;

const FormKicker = styled.div`
    display: inline-flex;
    align-items: center;
    gap: 7px;
    margin-bottom: 12px;
    color: #1674e6;
    font-size: 10.5px;
    font-weight: 800;
    letter-spacing: .22em;
    text-transform: uppercase;

    &::before {
        content: '';
        width: 16px;
        height: 2px;
        border-radius: 2px;
        background: linear-gradient(90deg, #00d9ff, #1674e6);
    }
`;

const FormHeading = styled.div`
    margin-bottom: 28px;

    h2 {
        margin: 0;
        color: #15283b;
        font-size: 28px;
        line-height: 1.2;
        font-weight: 800;
        letter-spacing: -.025em;
    }

    p {
        margin: 8px 0 0;
        color: #748394;
        font-size: 13px;
        line-height: 1.6;
    }

    @media (max-width: 760px) {
        margin-bottom: 20px;

        h2 {
            font-size: 26px;
        }
    }
`;

const StyledForm = styled(Form)`
    width: 100%;

    /* v7 fix: the individual field wrappers (username / password / button /
       forgot-password link) were rendering side-by-side instead of stacked,
       causing the label + input + button to visually overlap. Forcing this
       form into a column flex layout guarantees every direct child gets its
       own row no matter what display value it originally had. */
    display: flex;
    flex-direction: column;
    gap: 20px;

    @media (max-width: 760px) {
        gap: 16px;
    }

    > * {
        width: 100% !important;
        margin: 0 !important;
    }

    /* a wrapper that only contains a single link (e.g. "Forgot password?")
       reads better right-aligned under the button than stretched full-width */
    > div:has(> a:only-child) {
        width: auto !important;
        align-self: flex-end;
    }

    label,
    label span,
    .input-label {
        display: block !important;
        color: #526a80 !important;
        font-size: 11px !important;
        font-weight: 800 !important;
        letter-spacing: .12em !important;
        text-transform: uppercase;
        margin-bottom: 8px !important;
    }

    input,
    textarea,
    select {
        display: block;
        width: 100% !important;
        min-height: 52px;
        box-sizing: border-box;
        border: 1px solid #d1d9e2 !important;
        border-radius: 10px !important;
        background: #fff !important;
        color: #182a3b !important;
        /* 16px stops iOS Safari from auto-zooming into the field on focus */
        font-size: 16px !important;
        box-shadow: 0 2px 9px rgba(22, 41, 57, .035) !important;
        transition: border-color .16s ease, box-shadow .16s ease, transform .16s ease;
    }

    input:hover,
    textarea:hover,
    select:hover {
        border-color: #b7c4d1 !important;
    }

    input:focus,
    textarea:focus,
    select:focus {
        border-color: #1268d8 !important;
        box-shadow: 0 0 0 3px rgba(18,104,216,.11) !important;
        outline: 0 !important;
    }

    input::placeholder {
        color: #a3afbb !important;
    }

    button[type='submit'] {
        width: 100% !important;
        min-height: 56px;
        margin-top: 2px;
        border: 0 !important;
        border-radius: 10px !important;
        background: linear-gradient(135deg, #1674e6, #0b5ec6) !important;
        color: #fff !important;
        font-weight: 800 !important;
        letter-spacing: .08em;
        text-transform: uppercase;
        box-shadow: 0 12px 24px rgba(18,104,216,.24) !important;
        transition: transform .16s ease, box-shadow .16s ease, filter .16s ease;
    }

    button[type='submit']:hover {
        transform: translateY(-1px);
        filter: brightness(1.03);
        box-shadow: 0 16px 28px rgba(18,104,216,.29) !important;
    }

    button[type='submit']:active {
        transform: translateY(0);
    }

    a {
        color: #60758a !important;
        font-size: 11px !important;
        font-weight: 800 !important;
        letter-spacing: .10em !important;
        text-transform: uppercase;
        text-decoration: none !important;
    }

    a:hover {
        color: #1268d8 !important;
    }
`;

const SocialDivider = styled.div`
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 22px 0 14px;
    color: #8b9aaa;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: .16em;
    text-transform: uppercase;

    @media (max-width: 760px) {
        margin: 16px 0 12px;
        font-size: 9px;
    }

    &::before,
    &::after {
        content: '';
        flex: 1;
        height: 1px;
        background: #e4eaf0;
    }
`;

const SocialButtons = styled.div`
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;

    @media (max-width: 760px) {
        grid-template-columns: 1fr;
    }
`;

const SocialButton = styled.a<{ $provider: 'discord' | 'google' }>`
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 9px;
    min-height: 52px;
    box-sizing: border-box;
    padding: 10px 12px;
    border: 1px solid ${p => p.$provider === 'discord' ? '#5865f2' : '#d7dfe7'};
    border-radius: 12px;
    background: ${p => p.$provider === 'discord' ? 'linear-gradient(135deg, #6575ff, #4752c4)' : '#fff'};
    color: ${p => p.$provider === 'discord' ? '#fff' : '#263849'} !important;
    font-size: 12px !important;
    font-weight: 800 !important;
    letter-spacing: .04em !important;
    text-decoration: none !important;
    text-transform: none !important;
    box-shadow: ${p => p.$provider === 'discord' ? '0 10px 22px rgba(88,101,242,.24)' : '0 4px 12px rgba(20,43,64,.07)'};
    transition: transform .16s ease, box-shadow .16s ease, filter .16s ease;

    &:hover {
        color: ${p => p.$provider === 'discord' ? '#fff' : '#142b40'} !important;
        filter: brightness(1.04);
        transform: translateY(-1px);
        box-shadow: 0 8px 18px rgba(20, 43, 64, .12);
    }

    span {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 20px;
        height: 20px;
        border-radius: 6px;
        background: ${p => p.$provider === 'discord' ? 'rgba(255,255,255,.16)' : '#edf3fb'};
        color: ${p => p.$provider === 'discord' ? '#fff' : '#4285f4'};
        font-size: 16px;
        line-height: 1;
    }
`;

const AlertWrap = styled.div`
    margin-bottom: 16px;

    [role='alert'] {
        border-radius: 10px !important;
    }
`;

const OAuthError = styled.div`
    margin: 0 0 16px;
    padding: 12px 14px;
    border: 1px solid #f0c6c6;
    border-radius: 10px;
    background: #fff2f2;
    color: #9d3030;
    font-size: 12px;
    line-height: 1.55;
`;

const Footer = styled.footer`
    width: min(960px, 100%);
    flex: 0 0 auto;
    box-sizing: border-box;
    padding: 18px 0 2px;
    text-align: center;
    color: rgba(255,255,255,.74);
    font-size: 11px;

    @media (max-width: 760px) {
        width: min(480px, 100%);
        padding-top: 14px;
    }
`;

const FooterButtons = styled.div`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    flex-wrap: wrap;

    button {
        appearance: none;
        border: 1px solid rgba(255,255,255,.24);
        border-radius: 999px;
        padding: 8px 15px;
        background: rgba(0,0,0,.18);
        color: rgba(255,255,255,.88);
        cursor: pointer;
        font: inherit;
        font-weight: 700;
        letter-spacing: .04em;
        backdrop-filter: blur(10px);
        transition: background .16s ease, border-color .16s ease, transform .16s ease;
    }

    button:hover {
        background: rgba(15, 119, 212, .42);
        border-color: rgba(255,255,255,.44);
        transform: translateY(-1px);
    }
`;

const Copyright = styled.div`
    margin-top: 9px;
    color: rgba(255,255,255,.54);
    letter-spacing: .03em;
`;

const ModalOverlay = styled.div`
    position: fixed;
    inset: 0;
    z-index: 2000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 22px;
    box-sizing: border-box;
    background: rgba(0, 7, 12, .72);
    backdrop-filter: blur(9px);
`;

const Modal = styled.div`
    width: min(720px, 100%);
    max-height: min(80vh, 760px);
    overflow: auto;
    border: 1px solid rgba(255,255,255,.58);
    border-radius: 16px;
    background: rgba(255,255,255,.98);
    color: #24384b;
    box-shadow: 0 36px 100px rgba(0,0,0,.48);
`;

const ModalHeader = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 18px;
    padding: 18px 20px;
    border-bottom: 1px solid #e7edf3;

    h2 {
        margin: 0;
        color: #142b40;
        font-size: 21px;
        font-weight: 800;
    }

    button {
        width: 34px;
        height: 34px;
        border: 0;
        border-radius: 9px;
        background: #eef3f7;
        color: #5c6f80;
        cursor: pointer;
        font-size: 23px;
        line-height: 1;
    }
`;

const ModalBody = styled.div`
    padding: 22px;
    font-size: 14px;
    line-height: 1.7;

    h3 {
        margin: 0 0 8px;
        color: #19344e;
        font-size: 17px;
    }

    p { margin: 0 0 14px; }
`;

/* This component renders exactly ONE card, ONE logo and ONE footer.
   There is no DOM-injection fallback and no leftover markup from older
   theme versions living anywhere else in this file — install.sh resets
   wrapper.blade.php via git before this file is written, so nothing else
   on the page can duplicate what is rendered here. */
export default forwardRef<HTMLFormElement, Props>(({ title, ...props }, ref) => {
    const [modal, setModal] = useState<'impressum' | 'rechte' | null>(null);
    const [oauthError, setOauthError] = useState<string | null>(null);

    useEffect(() => {
        const message = new URLSearchParams(window.location.search).get('zypehost_oauth_error');
        if (message) {
            setOauthError(message);
            window.history.replaceState({}, document.title, window.location.pathname);
        }
    }, []);

    const closeModal = () => setModal(null);

    return (
        <Page>
            <AmbientOrb />
            <TitleBlock>
                <BrandMark><BrandBadge><img src={'/themes/zypehost/zypehost-icon.png?v=10'} alt={''} /></BrandBadge> ZypeHost</BrandMark>
                <Title>{title || 'Login to Continue'}</Title>
                <Subtitle>Secure access to your hosting control panel.</Subtitle>
            </TitleBlock>

            <Card>
                <FormPane>
                    <FormHeading>
                        <FormKicker>Account Access</FormKicker>
                        <h2>Welcome back</h2>
                        <p>Sign in with your ZypeHost account to continue.</p>
                    </FormHeading>

                    <AlertWrap>
                        <FlashMessageRender />
                    </AlertWrap>
                    {oauthError && <OAuthError role={'alert'}>{oauthError}</OAuthError>}

                    <SocialDivider>Or continue with</SocialDivider>
                    <SocialButtons>
                        <SocialButton href={'/auth/zypehost/discord'} $provider={'discord'}>
                            <span aria-hidden={'true'}>◈</span> Discord
                        </SocialButton>
                        <SocialButton href={'/auth/zypehost/google'} $provider={'google'}>
                            <span aria-hidden={'true'}>G</span> Google
                        </SocialButton>
                    </SocialButtons>

                    <StyledForm {...props} ref={ref}>
                        {props.children}
                    </StyledForm>
                </FormPane>

                <LogoPane>
                    <img src={'/themes/zypehost/zypehost-logo.png?v=12'} alt={'ZypeHost'} />
                </LogoPane>
            </Card>

            <Footer>
                <FooterButtons>
                    <button type={'button'} onClick={() => setModal('impressum')}>Impressum</button>
                    <button type={'button'} onClick={() => setModal('rechte')}>Rechte</button>
                </FooterButtons>
                <Copyright>Copyright ZypeHost {new Date().getFullYear()} ©️</Copyright>
            </Footer>

            {modal && (
                <ModalOverlay onMouseDown={closeModal}>
                    <Modal onMouseDown={(event) => event.stopPropagation()}>
                        <ModalHeader>
                            <h2>{modal === 'impressum' ? 'Impressum' : 'Rechte'}</h2>
                            <button type={'button'} aria-label={'Close'} onClick={closeModal}>×</button>
                        </ModalHeader>
                        <ModalBody>
                            {modal === 'impressum' ? (
                                <>
                                    <h3>Impressum</h3>
                                    <p><strong>Angaben gemäß § 5 DDG</strong><br />
                                        [Name oder Firma eintragen]<br />
                                        [Straße und Hausnummer eintragen]<br />
                                        [PLZ und Ort eintragen]<br />
                                        Deutschland</p>
                                    <p><strong>Kontakt</strong><br />
                                        E-Mail: <a href="mailto:info@zypehost.de" style={{ color: '#1268d8' }}>info@zypehost.de</a></p>
                                    <p><strong>Verantwortlich für den Inhalt nach § 18 Abs. 2 MStV</strong><br />
                                        [Name oder Firma eintragen]<br />
                                        [Straße und Hausnummer eintragen]<br />
                                        [PLZ und Ort eintragen]<br />
                                        Deutschland</p>
                                </>
                            ) : (
                                <>
                                    <h3>ZypeHost</h3>
                                    <p>Informationen zu Marken, Grafiken und eigenen Inhalten von ZypeHost werden hier veröffentlicht.</p>
                                    <p>Pterodactyl ist ein eigenständiges Open-Source-Projekt. Diese Login-Darstellung ist ein eigenes ZypeHost-Branding.</p>
                                    <p>Drittanbieter-Inhalte bleiben ihren jeweiligen Rechteinhabern zugeordnet.</p>
                                </>
                            )}
                        </ModalBody>
                    </Modal>
                </ModalOverlay>
            )}
        </Page>
    );
});
