# ZypeHost Pterodactyl Theme v21.0.6

GitHub-fertiges Komplettpaket für das ZypeHost-Pterodactyl-Panel. Das ZIP ist flach aufgebaut: `install.sh` liegt im obersten Ordner. Enthalten sind das bestehende ZypeHost-Theme, Discord-/Google-OAuth und die Minecraft-only Subdomain-Verwaltung über Cloudflare für genau `zyphost.de`.

## Enthaltene Funktionen

- ZypeHost Login- und Dashboard-Design, Logo, Hintergrund und Favicons.
- Login-Hintergrund mit dem mitgelieferten Server-Rack-Foto; die mobile Login-Seite scrollt vollständig bis zum Login-Button.
- Normale Pterodactyl-Anmeldung mit E-Mail/Benutzername und Passwort bleibt erhalten.
- Discord- und Google-OAuth mit State-Prüfung und verifizierter E-Mail.
- Google- und Discord-Anmeldung stehen in der mobilen Login-Ansicht sichtbar über dem Passwort-Formular.
- Auf Handys und Tablets erscheint links ein einklappbares Servermenü; es funktioniert für alle Servertypen. Auf Desktop bleibt die normale Navigation erhalten.
- Das mobile Menü hat einen größeren, beschrifteten Menüknopf und größere, besser antippbare Menüpunkte.
- Fügt den Tab „Subdomain“ selbst in die Servernavigation ein (direkt neben „Network“); es wird kein Drittanbieter-Tab vorausgesetzt.
- Korrigiert die Einfügestelle des Tabs in Listen- und Flex-Menüs, damit er als echter Menüpunkt direkt neben „Network“ erscheint.
- Subdomains können über „Schließen“ entfernt werden; dabei werden die zugehörigen Cloudflare-DNS-Einträge gelöscht.
- Prüft nach dem Frontend-Build, ob das Haupt-JavaScript-Bundle vorhanden ist; ein fehlendes Bundle lässt nur den Dashboard-Hintergrund stehen.
- Für Nicht-Minecraft-Eggs wird der Subdomain-Tab ausgeblendet; das Backend verweigert Anfragen für Nicht-Minecraft-Server zusätzlich serverseitig. Das mobile Servermenü bleibt auf allen Servern verfügbar.
- Kunden können ausschließlich eine Adresse unter `zyphost.de` erstellen.
- Minecraft-Java-Spieler geben nur die Subdomain ein; bei nicht standardmäßigen Ports wird der Port per SRV-DNS aufgelöst. Bei Bedrock oder anderen Clients kann weiterhin eine Portangabe nötig sein.
- Cloudflare erstellt für jede Subdomain einen nicht proxied A-Record. Bei Minecraft-Ports ungleich 25565 wird außerdem ein `_minecraft._tcp`-SRV-Record erstellt, damit Java-Spieler ohne Portangabe beitreten können.
- Subdomains können wieder gelöscht werden; das Backend löscht nur die in der ZypeHost-Datenbank gespeicherten Cloudflare-Record-IDs.
- Serverbesitzer und Root-Admins dürfen verwalten. Subuser brauchen die entsprechenden Pterodactyl-Allocation-Berechtigungen.
- Allocation-IP und -Port werden aus den dem Server zugewiesenen Pterodactyl-Allocations gelesen. Private IPs werden nicht als öffentliche DNS-Ziele akzeptiert; optional können öffentliche Node-IPs in der `.env` hinterlegt werden.
- Backup, Deinstallation, Reset und Paketprüfung.

## Wichtige technische Voraussetzungen

Das Paket zielt auf die vom Betreiber angegebene Panel-Struktur:

- Panel: `/var/www/pterodactyl`
- Auth-Routen: `routes/auth.php`
- Client-API-Routen: `routes/api-client.php`
- Login-Komponente: `resources/scripts/components/auth/LoginFormContainer.tsx`
- Blade-Wrapper: `resources/views/templates/wrapper.blade.php`
- Pterodactyl-Client-Middleware `ServerSubject`, `AuthenticateServerAccess` und `ResourceBelongsToServer`

Das Frontend-Skript fügt auf Handy und Tablet ein einklappbares Menü für die vorhandene Servernavigation ein. Es hängt nicht von der Minecraft-Erkennung ab. Nur der zusätzliche Menüpunkt „Subdomain“ wird nach erfolgreicher Minecraft-Prüfung angezeigt; ein Klick öffnet die Subdomain-Oberfläche als Panel-Overlay unter `/server/{identifier}/subdomains`.

Benötigt werden PHP 8.x mit Laravel/Pterodactyl-Abhängigkeiten, Python 3, Node.js und Yarn oder npm sowie eine funktionierende Datenbankverbindung.

## GitHub-Upload

1. ZIP herunterladen und lokal entpacken.
2. Alle Dateien und Ordner aus dem entpackten Inhalt direkt in das Hauptverzeichnis von `https://github.com/zyphostinfo-stack/Zyphostxd` hochladen.
3. Gleichnamige Dateien ersetzen und `Commit changes` ausführen.
4. Prüfen, dass `install.sh`, `backend/`, `scripts/` und `theme/` direkt auf der ersten Repository-Ebene liegen.
5. Nur `.env.example` hochladen. Eine echte Panel-`.env`, API-Token oder OAuth-Client-Secrets gehören niemals zu GitHub.

## Wenn nur der Hintergrund erscheint

Dann startet das Pterodactyl-Frontend wahrscheinlich nicht. Der Browser muss `/assets/bundle.<hash>.js` als JavaScript laden; wenn dieser Pfad stattdessen HTML oder `text/html` liefert, ist das Frontend-Bundle nicht erreichbar. Nach dem Hochladen des Pakets kann der Frontend-Build gezielt erneut ausgeführt werden:

```bash
cd /root/Zyphostxd
PTERODACTYL_DIR=/var/www/pterodactyl bash scripts/rebuild-frontend.sh
```

Das Skript baut nur das vorhandene Pterodactyl-Frontend neu, leert den Laravel-Cache und prüft, ob ein JavaScript-Bundle erzeugt wurde. Falls der Build fehlschlägt, ist die Fehlermeldung aus diesem Lauf entscheidend.

## Cloudflare vorbereiten

Erstelle bei Cloudflare einen API Token, der Zugriff auf die Zone `zyphost.de` hat und diese Rechte besitzt:

- Zone → DNS → Read
- Zone → DNS → Edit
- Zone → Zone → Read (wird vom Diagnose-Skript verwendet, um die Zone-ID zu prüfen)

Die Zone-ID von `zyphost.de` findest du in der Cloudflare-Zonenübersicht. Ein HTTP-403 beim Erstellen bedeutet üblicherweise, dass Token, Zone-ID oder die DNS-Read/Edit-Rechte nicht passen. Der Token wird nur auf dem Panelserver gespeichert. Der Code verwendet die Cloudflare DNS API mit Bearer-Token. A-Records werden immer mit `proxied: false` erstellt, da der normale Cloudflare-Webproxy keine direkten Minecraft-TCP-Verbindungen proxyt.

## Installation auf dem Server

Nach dem GitHub-Upload:

```bash
cd /root/Newwww
git pull --ff-only
chmod +x install.sh uninstall.sh reset.sh scripts/*.sh
PTERODACTYL_DIR=/var/www/pterodactyl bash ./install.sh 2>&1 | tee /root/zypehost-install-v21.0.6.log
```

Der Installer sichert die vorhandenen Dateien, kopiert Theme und Backend, fügt das mobile Servermenü ein, registriert OAuth- und Subdomain-Routen, ergänzt fehlende `.env`-Schlüssel und aktualisiert nur bekannte alte Standarddomains. Individuelle Einstellungen und echte Secrets werden nicht überschrieben. Anschließend führt er ausschließlich die zwei ZypeHost-Migrationen aus, baut das Frontend und prüft die registrierten Routen.

## `.env` konfigurieren

Der Installer ergänzt diese Schlüssel in `/var/www/pterodactyl/.env`, sofern sie fehlen:

```env
# Cloudflare – Token für die Zone zyphost.de
CLOUDFLARE_API_TOKEN=YOUR_CLOUDFLARE_API_TOKEN
CLOUDFLARE_ZONE_ID=YOUR_ZYPHOST_DE_ZONE_ID

# Subdomains
ZYPEHOST_SUBDOMAINS_ENABLED=true
ZYPEHOST_SUBDOMAINS_DOMAIN=zyphost.de
ZYPEHOST_SUBDOMAINS_MINECRAFT_ONLY=true
ZYPEHOST_SUBDOMAINS_MAX_PER_SERVER=1

# Optional: kommaseparierte Egg-IDs für exakte Minecraft-Freigabe.
# Wenn leer, prüft das Backend die Egg-/Nest-Namen (Minecraft, Paper, Purpur etc.).
ZYPEHOST_SUBDOMAINS_MINECRAFT_EGG_IDS=

# Optional, falls eine Allocation eine private IP enthält:
# Globale öffentliche IPv4 für alle Nodes:
ZYPEHOST_SUBDOMAINS_PUBLIC_IP=
# Oder je Node: NODE_ID:PUBLIC_IPV4,NODE_ID:PUBLIC_IPV4
ZYPEHOST_SUBDOMAINS_NODE_PUBLIC_IPS=
```

Die Domain ist im Backend fest auf `zyphost.de` gesetzt. Ein vom Browser übermittelter anderer Domainname wird nicht akzeptiert. Der Cloudflare-Proxy bleibt für Spielverkehr aus. Prüfe vor dem ersten Erstellen, dass `CLOUDFLARE_ZONE_ID` zur Zone `zyphost.de` gehört und der Token DNS-Lese- und Schreibrechte für diese Zone hat. Der Installer kann die Zone-ID nicht erraten oder sicher ersetzen. Trage `https://panel.zyphost.de/auth/zypehost/discord/callback` und `https://panel.zyphost.de/auth/zypehost/google/callback` außerdem in den jeweiligen OAuth-Portalen ein.

Vorhandene Einträge unter der alten Domain `blocknova.de` werden nicht automatisch migriert. Neue Subdomains verwenden `zyphost.de`.

Für Minecraft-Eggs mit ungewöhnlichen Namen empfiehlt sich eine explizite Liste der Egg-IDs. Diese IDs findest du in der Pterodactyl-Datenbank in der Tabelle `eggs`.

Danach die echten Discord-/Google-OAuth-Daten und die Cloudflare-Werte in `.env` eintragen. Cloudflare-Zugang und Zone zuerst prüfen:

```bash
cd /root/Zyphostxd
bash scripts/check-cloudflare.sh /var/www/pterodactyl/.env

cd /var/www/pterodactyl
php artisan optimize:clear
php artisan config:cache
```

## DNS-Verhalten

Für `survival.zyphost.de` wird ein A-Record auf die öffentliche IPv4-Adresse der ausgewählten Allocation erzeugt. Bei Ports ungleich 25565 wird zusätzlich `_minecraft._tcp.survival.zyphost.de` mit dem ausgewählten Port und `survival.zyphost.de` als Ziel angelegt. Das entspricht der Cloudflare-DNS-Record-API für A- und SRV-Records.

Wenn die Allocation eine private Adresse enthält, muss `ZYPEHOST_SUBDOMAINS_PUBLIC_IP` oder `ZYPEHOST_SUBDOMAINS_NODE_PUBLIC_IPS` gesetzt sein. Ohne öffentlich routbare IP wird die Erstellung verweigert, statt einen nicht erreichbaren DNS-Eintrag zu erstellen.

## Prüfen

```bash
cd /var/www/pterodactyl
php artisan route:list --path=zypehost
php artisan route:list --path=zypehost-subdomains
```

Die Subdomain-Endpunkte liegen unter:

- `GET /api/client/servers/{server}/zypehost-subdomains`
- `POST /api/client/servers/{server}/zypehost-subdomains`
- `DELETE /api/client/servers/{server}/zypehost-subdomains/{id}`

Der Live-Test zum Erstellen/Löschen benötigt einen gültigen Cloudflare-Token, die richtige Zone-ID und einen Minecraft-Server mit öffentlicher Allocation. Ein erfolgreicher PHP-/Build-Test ersetzt diesen Cloudflare-Live-Test nicht.

## Deinstallation

```bash
cd /root/Newwww
PTERODACTYL_DIR=/var/www/pterodactyl bash ./uninstall.sh
```

Der Installer stellt Panel-Dateien aus dem Backup wieder her. Die Migrationstabelle und bereits verwaltete Subdomain-Einträge werden nicht automatisch gelöscht, damit beim Entfernen des Themes keine Kundendaten oder DNS-Zuordnungen stillschweigend verloren gehen. DNS-Records bleiben bei Deinstallation bestehen und müssen bei Bedarf zuvor über das Panel entfernt werden.

## Sicherheitshinweise

- `.env`, Cloudflare-Token, OAuth-Secrets und API-Keys nie committen.
- Der Code überschreibt keine bereits vorhandenen DNS-Records; existierende Namen werden abgelehnt.
- DNS-Records werden ausschließlich per gespeicherter Record-ID gelöscht.
- Cloudflare A-Records werden grundsätzlich DNS-only erstellt.
- Nicht-Minecraft-Server werden im Backend abgewiesen, auch wenn jemand den API-Endpunkt manuell aufruft.
- Den Cloudflare-Token auf `zyphost.de` begrenzen und nicht den Global API Key verwenden.

## Paketprüfung

```bash
bash scripts/verify-package.sh
```

Syntaxprüfungen und simulierte Installationsabläufe sind keine Garantie für den produktiven Cloudflare- oder OAuth-Live-Betrieb. Vor dem Einsatz sollte ein Backup der Pterodactyl-Dateien und Datenbank vorliegen.
