#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

required=(
  install.sh uninstall.sh reset.sh README.md .gitignore .gitattributes .env.example VERSION
  theme/LoginFormContainer.tsx
  theme/public/themes/zypehost/background.jpeg
  theme/public/themes/zypehost/login-server-rack.jpg
  theme/public/themes/zypehost/dashboard-bg.jpg
  theme/public/themes/zypehost/zypehost-logo.png
  theme/public/themes/zypehost/zypehost-icon.png
  backend/routes/zypehost-oauth.php
  backend/controllers/OAuthController.php
  backend/config/zypehost.php
  backend/migrations/2026_10_31_000000_create_zypehost_oauth_accounts_table.php
  backend/controllers/SubdomainController.php
  backend/services/CloudflareDnsService.php
  backend/routes/zypehost-subdomains.php
  backend/routes/zypehost-subdomains-api.php
  backend/migrations/2026_11_03_000000_create_zypehost_subdomains_table.php
  theme/public/themes/zypehost/subdomains.js
  scripts/check-api.sh
  scripts/check-cloudflare.sh
  scripts/rebuild-frontend.sh
)
for file in "${required[@]}"; do
  [[ -f "$file" ]] || { echo "FEHLT: $file" >&2; exit 1; }
done

command -v php >/dev/null 2>&1 || { echo 'PHP fehlt; PHP-Prüfung übersprungen.' >&2; exit 2; }
command -v python3 >/dev/null 2>&1 || { echo 'python3 fehlt.' >&2; exit 2; }

while IFS= read -r -d '' file; do
  php -l "$file" >/dev/null
done < <(find backend -type f -name '*.php' -print0)
node --check theme/public/themes/zypehost/subdomains.js

git_shell_files=(install.sh uninstall.sh reset.sh scripts/check-api.sh scripts/check-cloudflare.sh scripts/rebuild-frontend.sh scripts/verify-package.sh)
for file in "${git_shell_files[@]}"; do bash -n "$file"; done

python3 - <<'PY'
from pathlib import Path
import re
root = Path('.')
install = (root / 'install.sh').read_text(encoding='utf-8')
route_file = (root / 'backend/routes/zypehost-oauth.php').read_text(encoding='utf-8')
ui = (root / 'theme/LoginFormContainer.tsx').read_text(encoding='utf-8')
env = (root / '.env.example').read_text(encoding='utf-8')
subdomains_js = (root / 'theme/public/themes/zypehost/subdomains.js').read_text(encoding='utf-8')
cloudflare_service = (root / 'backend/services/CloudflareDnsService.php').read_text(encoding='utf-8')
checks = {
    'auth.php route insertion': 'AUTH_ROUTES=' in install and "zypehost-oauth.php" in install,
    'route fallback ordering logic': 'Route::fallback' in install,
    'OAuth Discord and Google routes': all(x in route_file for x in ("discord|google", "OAuthController::class", "callback")),
    'Discord login button': '/auth/zypehost/discord' in ui,
    'Google login button': '/auth/zypehost/google' in ui,
    'mobile OAuth buttons appear before password form': ui.index("href={'/auth/zypehost/discord'}") < ui.index('<StyledForm'),
    'mobile OAuth buttons stack vertically': '@media (max-width: 760px)' in ui and 'grid-template-columns: 1fr;' in ui,
    'login uses the supplied server rack background': "login-server-rack.jpg?v=21.0.6" in ui,
    'mobile login page keeps content scrollable': 'overscroll-behavior-y: contain' in ui and '> * {' in ui and 'flex-shrink: 0;' in ui,
    'mobile login hides duplicate logo panel': re.search(r'const LogoPane\s*=.*?@media \(max-width: 760px\)\s*\{\s*display: none;', ui, re.S) is not None,
    'installer ships the login background asset': '"$SRC/login-server-rack.jpg" "$ASSET_DIR/login-server-rack.jpg"' in install,
    'OAuth secrets placeholders only': 'YOUR_DISCORD_CLIENT_SECRET' in env and 'YOUR_GOOGLE_CLIENT_SECRET' in env,
    'Cloudflare secret placeholder only': 'YOUR_CLOUDFLARE_API_TOKEN' in env,
    'no external raw image dependency': 'raw.githubusercontent.com' not in install,
    'no shell sourcing of Laravel env': 'source "$ENV_FILE"' not in (root / 'scripts/check-api.sh').read_text(encoding='utf-8'),
    'Cloudflare config keys': all(x in env for x in ('CLOUDFLARE_API_TOKEN', 'CLOUDFLARE_ZONE_ID', 'ZYPEHOST_SUBDOMAINS_MINECRAFT_ONLY')),
    'Minecraft-only domain locked': "'domain' => 'zyphost.de'" in (root / 'backend/config/zypehost.php').read_text(encoding='utf-8'),
    'Cloudflare DNS is never proxied': "'proxied' => false" in (root / 'backend/services/CloudflareDnsService.php').read_text(encoding='utf-8'),
    'Minecraft SRV support': "createMinecraftSrvRecord" in (root / 'backend/services/CloudflareDnsService.php').read_text(encoding='utf-8'),
    'non-Minecraft API guard': 'minecraft_only' in (root / 'backend/controllers/SubdomainController.php').read_text(encoding='utf-8'),
    'server tab UI script': '/themes/zypehost/subdomains.js' in install and 'ZYPEHOST_SUBDOMAIN_UI' in install,
    'own server navigation tab is injected': 'ensureSubdomainTab' in (root / 'theme/public/themes/zypehost/subdomains.js').read_text(encoding='utf-8') and 'data-zypehost-subdomain-tab' in (root / 'theme/public/themes/zypehost/subdomains.js').read_text(encoding='utf-8'),
    'mobile and tablet server menu works independently of Minecraft': 'ensureMobileNav(context.id)' in subdomains_js and '@media(max-width:1024px)' in subdomains_js and "loadServer(context.id).then" in subdomains_js,
    'mobile menu has a large labeled trigger and expanded touch targets': 'min-width:96px!important' in subdomains_js and 'height:48px!important' in subdomains_js and 'zypehost-mobile-nav-label">Menü' in subdomains_js and 'min-height:50px!important' in subdomains_js,
    'desktop keeps the normal server navigation': '@media(min-width:1025px)' in subdomains_js and '[data-zypehost-mobile-nav-toggle="1"]{display:none!important}' in subdomains_js,
    'subdomain close action calls the delete API': 'Subdomain schließen' in subdomains_js and "api(serverId, 'DELETE'" in subdomains_js,
    'Minecraft Java users see and copy only the hostname': 'Minecraft Java: nur diese Adresse eingeben' in subdomains_js and 'data-copy="' + "' + escapeHtml(item.fqdn) + '" in subdomains_js and 'escapeHtml(item.ip) + \':\' + escapeHtml(item.port)' not in subdomains_js,
    'non-default Minecraft port is handled by an SRV record': "if ((int) $allocation->port !== 25565)" in (root / 'backend/controllers/SubdomainController.php').read_text(encoding='utf-8') and 'createMinecraftSrvRecord' in cloudflare_service,
    'legacy domain defaults migrate without replacing credentials': 'CLOUDFLARE_ZONE_ID' in (root / 'install.sh').read_text(encoding='utf-8') and 'YOUR_ZYPHOST_DE_ZONE_ID' in env,
    'server tab is inserted beside list items': "linkParent.insertAdjacentElement('afterend', wrapper)" in (root / 'theme/public/themes/zypehost/subdomains.js').read_text(encoding='utf-8') and 'insertAfter.insertAdjacentElement(\'afterend\', insertion)' not in (root / 'theme/public/themes/zypehost/subdomains.js').read_text(encoding='utf-8'),
    'custom tab click opens the overlay route': 'event.preventDefault();' in (root / 'theme/public/themes/zypehost/subdomains.js').read_text(encoding='utf-8') and "'/subdomains'" in (root / 'theme/public/themes/zypehost/subdomains.js').read_text(encoding='utf-8'),
    'Cloudflare 403 explains token permissions': all(x in cloudflare_service for x in ('HTTP 403', 'zyphost.de', 'Zone → DNS → Read', 'Zone → DNS → Edit')),
}
for name, okay in checks.items():
    print(('OK' if okay else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
PY

echo 'ZypeHost package verification passed.'
