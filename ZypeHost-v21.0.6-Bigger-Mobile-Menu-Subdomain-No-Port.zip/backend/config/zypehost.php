<?php

$domains = array_filter(array_map('trim', explode(',', (string) env('ZYPEHOST_OAUTH_ALLOWED_DOMAINS', ''))));
$eggIds = array_filter(array_map('trim', explode(',', (string) env('ZYPEHOST_SUBDOMAINS_MINECRAFT_EGG_IDS', ''))));
$nodeIps = [];
$nodeMappings = array_filter(array_map('trim', explode(',', (string) env('ZYPEHOST_SUBDOMAINS_NODE_PUBLIC_IPS', ''))));
foreach ($nodeMappings as $mapping) {
    if (str_contains($mapping, ':')) {
        [$nodeId, $ip] = explode(':', $mapping, 2);
        if (ctype_digit($nodeId) && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $nodeIps[$nodeId] = $ip;
        }
    }
}

return [
    'oauth' => [
        'discord' => [
            'client_id' => env('ZYPEHOST_OAUTH_DISCORD_CLIENT_ID'),
            'client_secret' => env('ZYPEHOST_OAUTH_DISCORD_CLIENT_SECRET'),
            'redirect_uri' => env('ZYPEHOST_OAUTH_DISCORD_REDIRECT_URI'),
        ],
        'google' => [
            'client_id' => env('ZYPEHOST_OAUTH_GOOGLE_CLIENT_ID'),
            'client_secret' => env('ZYPEHOST_OAUTH_GOOGLE_CLIENT_SECRET'),
            'redirect_uri' => env('ZYPEHOST_OAUTH_GOOGLE_REDIRECT_URI'),
        ],
        'auto_register' => filter_var(env('ZYPEHOST_OAUTH_AUTO_REGISTER', true), FILTER_VALIDATE_BOOLEAN),
        'link_existing_email' => filter_var(env('ZYPEHOST_OAUTH_LINK_EXISTING_EMAIL', true), FILTER_VALIDATE_BOOLEAN),
        'allowed_domains' => array_map('strtolower', array_values($domains)),
    ],
    'api' => [
        'url' => rtrim((string) env('ZYPEHOST_API_URL', 'https://zypehost.blocknova.de/api/v1/admin'), '/'),
        'key' => env('ZYPEHOST_API_KEY'),
        'key_header' => env('ZYPEHOST_API_KEY_HEADER', 'Authorization'),
        'key_prefix' => env('ZYPEHOST_API_KEY_PREFIX', 'Bearer'),
    ],
    'subdomains' => [
        'enabled' => filter_var(env('ZYPEHOST_SUBDOMAINS_ENABLED', true), FILTER_VALIDATE_BOOLEAN),
        // This package deliberately exposes exactly one customer domain.
        'domain' => 'zyphost.de',
        'max_per_server' => max(1, (int) env('ZYPEHOST_SUBDOMAINS_MAX_PER_SERVER', 1)),
        'minecraft_egg_ids' => array_map('intval', array_values($eggIds)),
        'public_ip' => env('ZYPEHOST_SUBDOMAINS_PUBLIC_IP'),
        'node_public_ips' => $nodeIps,
        'cloudflare' => [
            'token' => env('CLOUDFLARE_API_TOKEN'),
            'zone_id' => env('CLOUDFLARE_ZONE_ID'),
        ],
    ],
];
