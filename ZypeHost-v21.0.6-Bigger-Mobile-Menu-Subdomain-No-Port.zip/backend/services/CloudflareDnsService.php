<?php

namespace Pterodactyl\Services\ZypeHost;

use Illuminate\Support\Facades\Http;
use RuntimeException;

class CloudflareDnsService
{
    private string $baseUrl;
    private string $zoneId;
    private string $token;

    public function __construct()
    {
        $this->token = (string) config('zypehost.subdomains.cloudflare.token', '');
        $this->zoneId = (string) config('zypehost.subdomains.cloudflare.zone_id', '');
        if ($this->token === '' || $this->zoneId === '') {
            throw new RuntimeException('Cloudflare ist nicht konfiguriert. CLOUDFLARE_API_TOKEN und CLOUDFLARE_ZONE_ID fehlen.');
        }
        $this->baseUrl = 'https://api.cloudflare.com/client/v4/zones/' . rawurlencode($this->zoneId) . '/dns_records';
    }

    /** @return array<int, array<string, mixed>> */
    public function recordsForName(string $name): array
    {
        $payload = $this->request('get', $this->baseUrl, ['name' => $name, 'per_page' => 100]);
        return is_array($payload['result'] ?? null) ? $payload['result'] : [];
    }

    /** @return array<string, mixed> */
    public function createARecord(string $fqdn, string $ip, string $comment): array
    {
        return $this->request('post', $this->baseUrl, [
            'type' => 'A',
            'name' => $fqdn,
            'content' => $ip,
            'ttl' => 1,
            'proxied' => false,
            'comment' => $comment,
        ])['result'] ?? [];
    }

    /** @return array<string, mixed> */
    public function createMinecraftSrvRecord(string $fqdn, int $port, string $comment): array
    {
        return $this->request('post', $this->baseUrl, [
            'type' => 'SRV',
            'name' => '_minecraft._tcp.' . $fqdn,
            'ttl' => 1,
            'comment' => $comment,
            'data' => [
                'priority' => 0,
                'weight' => 0,
                'port' => $port,
                'target' => $fqdn,
            ],
        ])['result'] ?? [];
    }

    public function deleteRecord(string $recordId): void
    {
        if ($recordId === '') {
            return;
        }

        $url = $this->baseUrl . '/' . rawurlencode($recordId);
        $response = Http::withToken($this->token)
            ->acceptJson()
            ->timeout(20)
            ->delete($url);

        // Cloudflare may already have removed a record manually. Treat 404 as
        // deleted so the customer can still remove the saved ZypeHost entry.
        if ($response->status() === 404) {
            return;
        }

        $json = $response->json();
        if (!$response->successful() || !($json['success'] ?? false)) {
            throw new RuntimeException($this->errorMessage($response->status(), $json));
        }
    }

    /** @return array<string, mixed> */
    private function request(string $method, string $url, array $data = []): array
    {
        $request = Http::withToken($this->token)->acceptJson()->timeout(20);
        $response = $method === 'get'
            ? $request->get($url, $data)
            : $request->post($url, $data);
        $json = $response->json();

        if (!$response->successful() || !is_array($json) || !($json['success'] ?? false)) {
            throw new RuntimeException($this->errorMessage($response->status(), is_array($json) ? $json : []));
        }

        return $json;
    }

    private function errorMessage(int $status, array $json): string
    {
        $messages = [];
        foreach (($json['errors'] ?? []) as $error) {
            if (is_array($error) && isset($error['message'])) {
                $messages[] = (string) $error['message'];
            }
        }

        $detail = implode('; ', array_slice($messages, 0, 3));
        if ($status === 401) {
            return 'Cloudflare API Fehler (HTTP 401): Der API-Token ist ungültig oder abgelaufen. Prüfe CLOUDFLARE_API_TOKEN. '
                . ($detail !== '' ? 'Cloudflare: ' . $detail : '');
        }
        if ($status === 403) {
            return 'Cloudflare API Fehler (HTTP 403): Der Token darf diese DNS-Abfrage nicht ausführen. '
                . 'Prüfe, ob er auf die Zone zyphost.de begrenzt ist und die Rechte Zone → DNS → Read und Zone → DNS → Edit besitzt. '
                . ($detail !== '' ? 'Cloudflare: ' . $detail : '');
        }

        return 'Cloudflare API Fehler (HTTP ' . $status . ')' . ($detail !== '' ? ': ' . $detail : '.');
    }
}
